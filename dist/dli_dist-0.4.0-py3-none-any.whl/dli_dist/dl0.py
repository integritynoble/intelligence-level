"""dli-dl0 — one declared operation, executed deterministically.

RULING 2's DL0: *one declared operation, executed. Deterministic tool invocation,
no strategy.* This module has **no planner, no model client, no retry strategy**,
and it imports nothing that can reach a network or a model — a property the
``ast`` check in ``tools/check_no_network_imports.py`` enforces, and the exit
criterion (CRITERION.md) demonstrates by removing the network and running it.

What it does
------------
``execute(contract)`` runs exactly one operation named by the contract, drawn
from a **closed set** (``OPERATIONS``). An operation outside the set is a
``specification`` failure — a refusal, not an improvised attempt. It captures the
argv it ran, the exit code, the artifacts it left, and the wall clock, writes
that run detail to an artifact file, and returns an **episode record** that
references it. The record carries **no verdict**: ``verification`` and ``result``
are null and there is no code path here that fills them.

The dl0 contract (this lane's own JSON format; a superset of what a brain hands a
DL0 component, carrying what a complete episode record needs)::

    {
      "task_id": "...",
      "operation": "hash_file" | "compare_bytes" | "run_argv",
      "args": { ... per operation ... },
      "kappa": {"verifiability": <int>, "risk": <int>},
      "kappa_provenance": {"benchmark_task_id": "<row in the pinned benchmark>"},
      "acceptance": {"locus","alpha","verifier_id","events",
                     "self_authored_criteria","root_criterion_declared_at",
                     "false_pass_rate"?},
      "loss": {"value","c_det","c_undo","c_residual"},
      "predicted_band": "T1"?,           # default T1
      "intervention_budget": "H0"?,      # default H0
      "artifacts_dir": "<abs path>"?     # default: a fresh temp dir
    }

``kappa`` is **read, never chosen**: dl0 verifies it against the pinned benchmark
(``dli_dist.kappa``) and refuses a contract whose kappa has no provenance. A
contract that carries no benchmark-provenanced kappa cannot yield a valid episode
record — the schema requires an integer ``verifiability`` — so dl0 refuses rather
than invent one.

Stdlib only.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dli_dist import episode, kappa
from dli_dist._record import ContractError, resolve_blocks

__all__ = [
    "OPERATIONS",
    "MAX_ARTIFACT_BYTES",
    "EXECUTOR_ID",
    "ContractError",
    "execute",
]

EXECUTOR_ID = "dli-dl0"

#: dl0 is a PERFORMER, not an acceptor: it does the work, it never judges it.
#: This is the single source of truth for the ``acceptance_role`` field of its
#: capabilities document AND for the role it hands ``episode.draft_episode`` — so
#: a downloader reading ``--capabilities`` and the guard that refuses
#: self-certification cannot disagree about what dl0 is. False here means a record
#: emitted by dl0 that names dl0 as its own verifier is refused, no matter what
#: string it writes into ``locus`` (F6).
ACCEPTANCE_ROLE = False

#: The closed set of operations dl0 will attempt. Declared in `declared_limits`
#: of the capabilities document; anything outside it is a specification failure.
OPERATIONS = frozenset({"hash_file", "compare_bytes", "run_argv"})

#: Cap on bytes dl0 will read into memory for a hash/compare, so a contract
#: cannot turn a deterministic op into an unbounded one.
MAX_ARTIFACT_BYTES = 10 * 1024 * 1024


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _read_bytes(path: str) -> bytes:
    p = Path(path)
    if not p.is_file():
        raise ContractError(f"not a file: {path!r}", failure_class="tool_env")
    size = p.stat().st_size
    if size > MAX_ARTIFACT_BYTES:
        raise ContractError(
            f"{path!r} is {size} bytes, over the declared max {MAX_ARTIFACT_BYTES}"
        )
    return p.read_bytes()


# --- the closed set of operations -------------------------------------------
# Each returns (argv, exit_code, produced_artifacts, op_detail). argv is what the
# operation "ran" (a literal for pure-python ops, a real argv for run_argv);
# op_detail is the deterministic result, written to an artifact, never a verdict.


def _op_hash_file(args: dict[str, Any], out: Path) -> tuple[list[str], int, dict, dict]:
    path = args.get("path")
    if not isinstance(path, str):
        raise ContractError("hash_file needs args.path (a string)")
    algo = args.get("algo", "sha256")
    if algo not in hashlib.algorithms_guaranteed:
        raise ContractError(f"unsupported hash algo {algo!r}")
    data = _read_bytes(path)
    digest = hashlib.new(algo, data).hexdigest()
    detail = {"operation": "hash_file", "path": str(Path(path).resolve()),
              "algo": algo, "digest": digest, "bytes": len(data)}
    result_file = out / "hash_file.result.json"
    result_file.write_text(json.dumps(detail, indent=2, sort_keys=True), encoding="utf-8")
    argv = ["dl0:hash_file", f"algo={algo}", str(Path(path).resolve())]
    return argv, 0, {"hash_result": str(result_file)}, detail


def _op_compare_bytes(args: dict[str, Any], out: Path) -> tuple[list[str], int, dict, dict]:
    a, b = args.get("path_a"), args.get("path_b")
    if not isinstance(a, str) or not isinstance(b, str):
        raise ContractError("compare_bytes needs args.path_a and args.path_b (strings)")
    da, db = _read_bytes(a), _read_bytes(b)
    equal = da == db
    detail = {
        "operation": "compare_bytes",
        "path_a": str(Path(a).resolve()), "path_b": str(Path(b).resolve()),
        "sha256_a": hashlib.sha256(da).hexdigest(),
        "sha256_b": hashlib.sha256(db).hexdigest(),
        # A measurement of the two byte strings, NOT a verdict about a task.
        "equal": equal,
    }
    result_file = out / "compare_bytes.result.json"
    result_file.write_text(json.dumps(detail, indent=2, sort_keys=True), encoding="utf-8")
    argv = ["dl0:compare_bytes", str(Path(a).resolve()), str(Path(b).resolve())]
    return argv, 0, {"compare_result": str(result_file)}, detail


def _op_run_argv(args: dict[str, Any], out: Path) -> tuple[list[str], int, dict, dict]:
    argv = args.get("argv")
    if not isinstance(argv, list) or not argv or not all(isinstance(x, str) for x in argv):
        raise ContractError("run_argv needs args.argv (a non-empty list of strings)")
    stdout_file, stderr_file = out / "run_argv.stdout", out / "run_argv.stderr"
    # No shell, declared argv only, no network setup by dl0 itself. Whatever the
    # child does is the contract's granted authority, not dl0's improvisation.
    with stdout_file.open("wb") as so, stderr_file.open("wb") as se:
        proc = subprocess.run(argv, stdout=so, stderr=se, check=False)
    detail = {"operation": "run_argv", "argv": list(argv), "exit_code": proc.returncode}
    result_file = out / "run_argv.result.json"
    result_file.write_text(json.dumps(detail, indent=2, sort_keys=True), encoding="utf-8")
    artifacts = {
        "run_result": str(result_file),
        "stdout": str(stdout_file),
        "stderr": str(stderr_file),
    }
    return list(argv), proc.returncode, artifacts, detail


_DISPATCH = {
    "hash_file": _op_hash_file,
    "compare_bytes": _op_compare_bytes,
    "run_argv": _op_run_argv,
}


def execute(contract: dict[str, Any]) -> dict[str, Any]:
    """Run the contract's one operation and return an episode record.

    Raises ``ContractError`` (with a ``failure_class``) when the contract is
    defective in a way that prevents building a valid record at all — a missing
    or unprovenanced kappa, or a missing required block. When the contract is
    well-formed but names an operation outside the closed set, a record IS built
    with ``failure_class="specification"`` documenting the refusal.
    """
    if "task_id" not in contract:
        raise ContractError("contract missing required field 'task_id'")
    if "operation" not in contract:
        raise ContractError("contract missing required field 'operation'")
    task_id = contract["task_id"]
    operation = contract["operation"]

    # kappa is read from the pinned benchmark, never chosen; an invented kappa is
    # refused here, before any operation runs. loss and acceptance come from the
    # brain-declared blocks, with sigma and p* derived, never quoted.
    blocks = resolve_blocks(contract)
    kappa_block = blocks["kappa"]
    loss_block = blocks["loss"]
    acceptance_block = blocks["acceptance"]

    out = Path(contract.get("artifacts_dir") or tempfile.mkdtemp(prefix="dli-dl0-"))
    out.mkdir(parents=True, exist_ok=True)

    started = _now()
    failure_class: str | None = None
    if operation not in OPERATIONS:
        # Well-formed contract, out-of-set operation: a refusal, documented.
        argv = ["dl0:refused", str(operation)]
        exit_code = 64  # EX_USAGE-ish; a specification refusal is non-zero.
        failure_class = "specification"
        detail = {
            "operation": operation, "refused": True,
            "reason": f"operation {operation!r} not in declared set {sorted(OPERATIONS)}",
        }
        refusal_file = out / "specification_refusal.json"
        refusal_file.write_text(json.dumps(detail, indent=2, sort_keys=True), encoding="utf-8")
        artifacts = {"specification_refusal": str(refusal_file)}
    else:
        argv, exit_code, artifacts, detail = _DISPATCH[operation](
            dict(contract.get("args") or {}), out
        )
        if exit_code != 0 and failure_class is None:
            # The declared child argv exited non-zero: an execution diagnosis,
            # not a verdict about the task.
            failure_class = "execution"
    ended = _now()

    # Write the run detail (argv, exit code, timestamps) to an artifact and
    # reference it from evidence. The episode record schema has no argv/exit_code
    # field by design: those are evidence, not ledger claims.
    run_record = {
        "executor_id": EXECUTOR_ID,
        "task_id": task_id,
        "argv": argv,
        "exit_code": exit_code,
        "started_at": started,
        "ended_at": ended,
        "artifacts": artifacts,
        "operation_detail": detail,
    }
    run_file = out / "execution_result.json"
    run_file.write_text(json.dumps(run_record, indent=2, sort_keys=True), encoding="utf-8")

    evidence = {"execution_result": str(run_file)}
    evidence.update(artifacts)

    latency = (
        episode.parse_instant(ended) - episode.parse_instant(started)
    ).total_seconds()

    record = episode.draft_episode(
        task_id=task_id,
        task_band=contract.get("predicted_band", "T1"),
        kappa=kappa_block,
        intervention_budget=contract.get("intervention_budget", "H0"),
        executor=EXECUTOR_ID,
        acceptance_role=ACCEPTANCE_ROLE,  # False: dl0 may never self-certify (F6).
        replans=0,               # DL0 does not replan.
        latency_seconds=max(latency, 0.0),
        loss=loss_block,
        acceptance=acceptance_block,
        evidence=evidence,
        held_level="DL0",
        opened_level="DL0",
        failure_class=failure_class,
        executor_stub=False,
        compute_cost=0.0,        # No LLM call. RULING 2 req 1.
        benchmark_assets_present=False,  # chassis run, not the exam.
    )
    # Stash the process exit code so the CLI can propagate it, without putting it
    # in the record (the record has no such field, and it is not a verdict).
    return {"record": record, "exit_code": exit_code}


def _main(argv: list[str]) -> int:
    """`exec --contract c.json` path, shared by the CLI. Returns a process exit code."""
    contract_path = None
    it = iter(argv)
    for tok in it:
        if tok == "--contract":
            contract_path = next(it, None)
    if not contract_path:
        sys.stderr.write("usage: dli-dl0 exec --contract <c.json>\n")
        return 2
    try:
        contract = json.loads(Path(contract_path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        sys.stderr.write(f"could not read/parse contract {contract_path!r}: {exc}\n")
        return 2
    try:
        outcome = execute(contract)
    except kappa.KappaPermissionError as exc:
        # Distinct from a provenance failure: the row is real but outside the
        # set this lane may read (F2 / RULING 3 §4.4).
        sys.stderr.write(f"REFUSED (charter: unpermitted benchmark row): {exc}\n")
        return 5
    except kappa.KappaProvenanceError as exc:
        sys.stderr.write(f"REFUSED (kappa provenance): {exc}\n")
        return 3
    except ContractError as exc:
        sys.stderr.write(f"REFUSED ({exc.failure_class}): {exc}\n")
        return 3
    except episode.EpisodeInvalid as exc:
        sys.stderr.write(f"could not build a valid episode record: {exc}\n")
        return 4
    json.dump(outcome["record"], sys.stdout, ensure_ascii=False)
    sys.stdout.write("\n")
    return outcome["exit_code"]


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
