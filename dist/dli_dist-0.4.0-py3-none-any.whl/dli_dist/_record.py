"""Shared episode-record block construction for the DL0 executors.

``dli-dl0`` and ``dli-accept`` both emit episode records, and both must resolve
kappa from the pinned benchmark, copy the brain-declared acceptance regime, and
derive the loss block the same way. Keeping that in one place stops the two
binaries from drifting on the exact risk-provenance string or the derivation of
sigma / p*. Stdlib only; imports nothing that reaches a network.
"""

from __future__ import annotations

from typing import Any

from dli_dist import episode, kappa

__all__ = ["ContractError", "resolve_blocks"]


class ContractError(Exception):
    """The contract is malformed or asks for something outside remit.

    Carries a ``failure_class`` (``specification`` for a contract defect) so the
    caller records the diagnosis. A diagnosis is not a verdict.
    """

    def __init__(self, message: str, failure_class: str = "specification") -> None:
        super().__init__(message)
        self.failure_class = failure_class


def _require(contract: dict[str, Any], key: str) -> Any:
    if key not in contract:
        raise ContractError(f"contract missing required field {key!r}")
    return contract[key]


def resolve_blocks(contract: dict[str, Any]) -> dict[str, Any]:
    """Build the kappa, loss and acceptance blocks common to every episode record.

    Verifies the contract's kappa against the pinned benchmark first — an
    invented kappa is refused here, before any work runs. Returns a dict with
    ``kappa``, ``loss`` and ``acceptance`` blocks ready for ``draft_episode``.
    Raises ``kappa.KappaProvenanceError`` or ``ContractError``.
    """
    acceptance_in = _require(contract, "acceptance")
    loss_in = _require(contract, "loss")

    kappa.verify_contract_kappa(contract)
    benchmark_task_id = contract["kappa_provenance"]["benchmark_task_id"]
    row = kappa.row_metadata(benchmark_task_id)
    risk = row.get("difficulty_risk")
    verifiability = (row.get("kappa") or {}).get("verifiability")
    # Names the pinned v0.2 file (which DOES carry a risk coordinate) without the
    # literal 'DLI-Bench' that the v0.1-era guard rejects for a filled risk.
    risk_prov = (
        f"dli_bench_tasks_v0_2.jsonl sha256:{kappa.BENCHMARK_SHA256[:8]} "
        f"field:difficulty_risk task:{benchmark_task_id}"
    )

    try:
        kappa_block = episode.kappa_block(
            verifiability=verifiability, risk=risk, risk_provenance=risk_prov
        )
        loss_block = episode.loss_block(
            value=loss_in["value"], c_det=loss_in["c_det"],
            c_undo=loss_in["c_undo"], c_residual=loss_in["c_residual"],
        )
        acceptance_block = episode.acceptance_block(
            locus=acceptance_in["locus"],
            alpha=acceptance_in["alpha"],
            verifier_id=acceptance_in["verifier_id"],
            events=acceptance_in["events"],
            self_authored_criteria=acceptance_in["self_authored_criteria"],
            root_criterion_declared_at=acceptance_in["root_criterion_declared_at"],
            false_pass_rate=acceptance_in.get("false_pass_rate"),
            verifier1_artifact=acceptance_in.get("verifier1_artifact"),
        )
    except KeyError as exc:
        raise ContractError(f"acceptance/loss block missing field {exc}") from exc
    except episode.EpisodeInvalid as exc:
        raise ContractError(str(exc)) from exc

    return {"kappa": kappa_block, "loss": loss_block, "acceptance": acceptance_block}
