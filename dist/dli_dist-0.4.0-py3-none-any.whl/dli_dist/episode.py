"""Build and validate merged episode records — with the two verdict holes kept open.

An executor reports **what it did**: the argv it ran, the exit code it got, the
artifacts it left, the clock it burned. It never reports whether that was good
enough. dl-brain's ``ExecutionResult`` has nowhere to put a verdict for exactly
this reason, and this lane's episode records honor the same rule: ``verification``
and ``result`` are emitted as ``null`` and there is no code path here that fills
them. The party that did the work is not the party that judges it.

Validation is two layers, matching ``vendor/dl-brain-<tier-sha8>/episode_record.schema.json``:

* structural (``jsonschema_lite``), and
* the derived-field checks dl-brain recomputes rather than trusts — sigma from
  its own numerator, rho and p* from the loss inputs, and the risk/provenance
  interlock (a null risk must be marked ``absent_from_benchmark``; a filled risk
  must not be). These are re-implemented here, not imported from dl-brain, so the
  binary stays stdlib-bare; a disagreement with the vendored schema is a defect
  to report, not to hide.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence

from dli_dist.jsonschema_lite import (
    ValidationError,
    load_schema_text,
    parse_instant,
)
from dli_dist import jsonschema_lite, _resources, _build

__all__ = [
    "EPISODE_SCHEMA_PATH",
    "ABSENT_FROM_BENCHMARK",
    "EpisodeInvalid",
    "loss_block",
    "acceptance_block",
    "kappa_block",
    "draft_episode",
    "validate_episode",
]

#: The source-checkout location, kept for reference. Loaded via
#: ``importlib.resources`` below so it resolves inside a wheel or a zipapp too.
#: The vendor directory is derived from ``_build.TIER_SHA[:8]`` rather than typed,
#: so the re-pinned tier SHA and this path cannot drift apart.
EPISODE_SCHEMA_PATH = (
    Path(__file__).resolve().parent.parent
    / "vendor"
    / f"dl-brain-{_build.TIER_SHA[:8]}"
    / "episode_record.schema.json"
)

_SCHEMA_CACHE: dict | None = None


def _episode_schema() -> dict:
    global _SCHEMA_CACHE
    if _SCHEMA_CACHE is None:
        _SCHEMA_CACHE = load_schema_text(
            _resources.schema_text(_resources.EPISODE_SCHEMA)
        )
    return _SCHEMA_CACHE

#: RULING.md §2: the marker a null risk coordinate must carry.
ABSENT_FROM_BENCHMARK = "absent_from_benchmark"

#: Loss-block recomputation tolerance. dl-brain uses 5e-4 (its schema.py notes a
#: reference record quotes p_star to three decimals); matched here so a record
#: this lane accepts is one dl-brain accepts, and vice versa. sigma is stricter.
_ROUNDING = 5e-4
_SIGMA_TOL = 1e-9


class EpisodeInvalid(Exception):
    """An episode record failed structural or derived validation."""


def _p_star(rho: float) -> float:
    """p* = rho / (1 + rho) (repair Proposition 3). Computed, never quoted."""
    return rho / (1.0 + rho)


def loss_block(
    *, value: float, c_det: float, c_undo: float, c_residual: float
) -> dict[str, float]:
    """Build the loss block with rho and p* derived from the four inputs.

    Producing them from the same inputs the validator recomputes from means a
    caller cannot hand-write a flattering p* and have it slip through.
    """
    rho = (c_det + c_undo + c_residual) / value
    return {
        "value": float(value),
        "c_det": float(c_det),
        "c_undo": float(c_undo),
        "c_residual": float(c_residual),
        "rho": rho,
        "p_star": _p_star(rho),
    }


#: The identity of the independent (alpha3) verifier party. Naming it in an
#: acceptance block claims it saw the run; a record that names it without a real
#: artifact from it is the same defect as a binary overstating its level.
VERIFIER1_ID = "verifier1"

#: F5/F6. ``acceptance.verifier_id == executor`` is the alpha0 case (accepted by
#: the performing system) wearing an alpha1 label — dl-brain's schema only rejects
#: the literal string ``alpha == "alpha0"`` and lets a self-certified record
#: through. The one honest case where the two ids coincide is an *accept run*,
#: whose ``executor`` IS the acceptor, checking an artifact produced by a distinct
#: subject. Such a record declares that subject in its free-string ``locus`` with
#: this grammar.
#:
#: F6 is the correction to F5: this grammar alone is NOT enough to admit the
#: coincidence. ``locus`` is written by the same party being restrained, so any
#: executor can type the magic string and self-certify. The exemption must instead
#: be keyed to the EMITTING BINARY'S ROLE — ``acceptance_role`` in its own
#: capabilities document, which the emitter of a single record cannot forge into
#: the record (episode ``additionalProperties`` is false). Role is checked FIRST;
#: the distinct-subject ``locus`` requirement is an ADDITIONAL condition on top,
#: not a substitute. Both must hold.
_ACCEPT_LOCUS_INFIX = " over artifact of "


def _accept_run_subject(locus: Any, verifier_id: str) -> str | None:
    """The distinct subject an accept-run ``locus`` names, or ``None``.

    Grammar: ``external:<verifier_id> over artifact of <subject>``. Returns the
    non-empty ``<subject>`` when the locus is such a declaration, else ``None``.
    """
    prefix = f"external:{verifier_id}{_ACCEPT_LOCUS_INFIX}"
    if isinstance(locus, str) and locus.startswith(prefix):
        subject = locus[len(prefix):].strip()
        return subject or None
    return None


def _reject_self_verifier(executor: Any, acc: Any, acceptance_role: bool) -> None:
    """Refuse a record that names its performer as its own verifier (F5/F6).

    The performing system may not verify itself. ``acceptance.verifier_id ==
    executor`` is admissible in exactly one case, and only when BOTH conditions
    hold:

    * ``acceptance_role`` — the EMITTING BINARY is an acceptance-role binary, as
      declared in its own ``--capabilities`` document (``acceptance_role: true``).
      This is the F6 correction: the exemption is keyed to the identity of the
      party that ran, not to any string that party wrote into this record. Only
      ``dli-accept`` carries the role; ``dli-dl0``..``dli-dl3`` and ``dli-bench``
      do not. A caller that cannot establish the emitter's role passes ``False``
      (the safe default) and the coincidence is refused outright.
    * the ``locus`` names a distinct subject — an accept run over *another*
      party's artifact, per the ``external:<verifier_id> over artifact of
      <subject>`` grammar. Kept from F5 as an ADDITIONAL condition: a role alone
      is not a licence to name yourself as your own subject.

    Anything else is self-certification and is refused, exactly as ``alpha0`` is.
    """
    if not isinstance(acc, dict) or not isinstance(executor, str):
        return
    verifier_id = acc.get("verifier_id")
    if verifier_id != executor:
        return
    subject = _accept_run_subject(acc.get("locus"), verifier_id)
    if acceptance_role and subject is not None and subject != executor:
        return  # legitimate accept run by an acceptance-role binary over a distinct subject
    raise EpisodeInvalid(
        f"executor {executor!r} is named as its own verifier "
        "(acceptance.verifier_id == executor): the performing system may not "
        "verify itself. That is the alpha0 case (accepted by the performer) "
        "wearing an alpha1 label, which dl-brain's schema does not catch. The "
        "coincidence is admissible only for an acceptance-role binary "
        "(acceptance_role=true in its own capabilities document — not a claim made "
        "in this record, F6) AND only over a distinct subject declared in locus as "
        f"'external:{verifier_id}{_ACCEPT_LOCUS_INFIX}<subject>'. Name the party "
        "that will accept the work instead."
    )


def acceptance_block(
    *,
    locus: str,
    alpha: str,
    verifier_id: str,
    events: int,
    self_authored_criteria: int,
    root_criterion_declared_at: str,
    false_pass_rate: float | None = None,
    excluded_classes: int | None = None,
    verifier1_artifact: str | None = None,
) -> dict[str, Any]:
    """Build the acceptance block with sigma derived from its own numerator.

    This describes the acceptance *regime* declared before the work — who will
    judge (``verifier_id``, non-null always), at what level (``alpha``, never
    ``alpha0``), against a criterion declared at ``root_criterion_declared_at``.
    It is NOT a verdict; the verdict fields live elsewhere and stay null. An
    executor fills this from the contract it was handed, not from its own
    opinion.

    A block may name ``verifier1`` — the independent alpha3 party — only when a
    real ``verifier1_artifact`` path is present and points at an existing file.
    ``verifier1`` never touched a run this lane produces from this account, so a
    block naming it without that artifact overstates who verified the record and
    is refused (F3). ``alpha0`` is inadmissible and refused outright.
    """
    if alpha == "alpha0":
        raise EpisodeInvalid(
            "alpha0 (accepted by the performing system) is inadmissible: that is "
            "an assertion, not a level"
        )
    if VERIFIER1_ID in verifier_id:
        artifact_ok = (
            isinstance(verifier1_artifact, str)
            and verifier1_artifact != ""
            and Path(verifier1_artifact).is_file()
        )
        if not artifact_ok:
            raise EpisodeInvalid(
                f"acceptance names {verifier_id!r} but no real verifier1 artifact "
                "path is present — verifier1 (the independent alpha3 party) did "
                "not touch this run, and naming it as the verifier of a record it "
                "never saw is a downloadable overstatement (F3). Name the process "
                "that actually ran, or supply verifier1_artifact pointing at a "
                "real artifact from verifier1."
            )
    block: dict[str, Any] = {
        "locus": locus,
        "alpha": alpha,
        "verifier_id": verifier_id,
        "false_pass_rate": false_pass_rate,
        "events": int(events),
        "self_authored_criteria": int(self_authored_criteria),
        "sigma": 0.0 if events == 0 else self_authored_criteria / events,
        "root_criterion_declared_at": root_criterion_declared_at,
    }
    if excluded_classes is not None:
        block["excluded_classes"] = int(excluded_classes)
    return block


def kappa_block(
    *, verifiability: int, risk: int | None, risk_provenance: str
) -> dict[str, Any]:
    """Build the kappa block, enforcing the risk/provenance interlock locally.

    A null risk must be marked ``absent_from_benchmark``; a filled risk must not
    be. The value is risk on the increasing scale 0 = trivially undoable,
    5 = irreversible.
    """
    if risk is None and risk_provenance != ABSENT_FROM_BENCHMARK:
        raise EpisodeInvalid(
            f"risk is null but provenance is {risk_provenance!r}; a hole must be "
            f"marked {ABSENT_FROM_BENCHMARK!r} (RULING.md §2)"
        )
    if risk is not None and risk_provenance == ABSENT_FROM_BENCHMARK:
        raise EpisodeInvalid("risk is filled but attributed to its own absence")
    return {
        "verifiability": int(verifiability),
        "risk": risk,
        "risk_provenance": risk_provenance,
    }


def draft_episode(
    *,
    task_id: str,
    task_band: str,
    kappa: Mapping[str, Any],
    intervention_budget: str,
    executor: str,
    replans: int,
    latency_seconds: float,
    loss: Mapping[str, float],
    acceptance: Mapping[str, Any],
    acceptance_role: bool = False,
    interventions: Sequence[Mapping[str, Any]] = (),
    difficulty_vector: Mapping[str, int] | None = None,
    evidence: Mapping[str, str] | None = None,
    held_level: str | None = None,
    opened_level: str | None = None,
    failure_class: str | None = None,
    executor_stub: bool = False,
    compute_cost: float | None = None,
    benchmark_assets_present: bool = False,
    validate: bool = True,
) -> dict[str, Any]:
    """Build one episode record with the verdict fields left null.

    ``verification`` and ``result`` are always ``None`` and there is no argument
    to set them: this is the structural enforcement of the acceptance separation.

    ``acceptance_role`` is the EMITTING BINARY'S role, read from its own
    capabilities document (``dl0.ACCEPTANCE_ROLE`` / ``accept.ACCEPTANCE_ROLE``),
    never inferred from the contract or the record. It gates the one case where
    ``acceptance.verifier_id == executor`` is admissible (an accept run); it
    defaults ``False`` so a caller that has not established the emitter's role
    cannot accidentally license self-certification (F6).
    """
    record: dict[str, Any] = {
        "task_id": task_id,
        "task_band": task_band,
        "kappa": dict(kappa),
        "intervention_budget": intervention_budget,
        "human_interventions": [dict(iv) for iv in interventions],
        "acceptance": dict(acceptance),
        "loss": dict(loss),
        "executor": executor,
        "executor_stub": bool(executor_stub),
        "agent_replans": int(replans),
        # The two holes. Written by an acceptor, never here.
        "verification": None,
        "result": None,
        "latency_seconds": float(latency_seconds),
        "compute_cost": compute_cost,
        "held_level": held_level,
        "opened_level": opened_level,
        "failure_class": failure_class,
        "benchmark_assets_present": bool(benchmark_assets_present),
    }
    if difficulty_vector is not None:
        record["difficulty_vector"] = dict(difficulty_vector)
    if evidence is not None:
        record["evidence"] = dict(evidence)
    # Fires regardless of the ``validate`` flag, the way the verifier1 guard does:
    # self-certification is refused at construction, not only at validation.
    _reject_self_verifier(executor, record["acceptance"], acceptance_role)
    if validate:
        validate_episode(record, acceptance_role=acceptance_role)
    return record


def validate_episode(
    record: Mapping[str, Any],
    schema: dict | None = None,
    acceptance_role: bool = False,
) -> None:
    """Validate against the vendored schema plus the derived-field checks.

    Raises ``EpisodeInvalid`` on the first violation, else returns None.

    ``acceptance_role`` is the role of the binary that EMITTED ``record``,
    established out of band (from its capabilities document), never from the
    record — a record cannot carry a trustworthy statement of its own emitter's
    role. It defaults ``False``: a party validating a bare downloaded record that
    names its performer as its own verifier gets no exemption unless it can
    independently vouch that the emitter is an acceptance-role binary (F6).
    """
    if schema is None:
        schema = _episode_schema()
    try:
        jsonschema_lite.validate(record, schema)
    except ValidationError as exc:
        raise EpisodeInvalid(f"structure: {exc}") from exc
    _derived_checks(record, acceptance_role)


def _derived_checks(inst: Mapping[str, Any], acceptance_role: bool = False) -> None:
    acc = inst.get("acceptance")
    if isinstance(acc, dict):
        events = acc.get("events")
        self_authored = acc.get("self_authored_criteria")
        sigma = acc.get("sigma")
        if isinstance(events, int) and isinstance(self_authored, int):
            if self_authored > events:
                raise EpisodeInvalid(
                    f"self_authored_criteria ({self_authored}) exceeds events ({events})"
                )
            expected = 0.0 if events == 0 else self_authored / events
            if isinstance(sigma, (int, float)) and abs(sigma - expected) > _SIGMA_TOL:
                raise EpisodeInvalid(
                    f"sigma {sigma} disagrees with {self_authored}/{events} = "
                    f"{expected} — sigma is derived, not declared"
                )
        if acc.get("alpha") == "alpha0":
            raise EpisodeInvalid(
                "alpha0 (accepted by the performing system) is inadmissible: "
                "that is an assertion, not a level"
            )
        if "false_pass_rate" not in acc:
            raise EpisodeInvalid(
                "false_pass_rate absent; null is required when unknown — absent "
                "and null are not the same statement"
            )
        # F5/F6: a derived check a downloader gets for free — the performer may
        # not be named as its own verifier. dl-brain's schema misses this; this
        # does not. Kept here as well as at construction so validating a foreign
        # record (never built through draft_episode) is protected too. The
        # exemption is keyed to the emitter's role, supplied by the caller out of
        # band; with the default False, a bare foreign self-verifying record is
        # refused rather than trusted.
        _reject_self_verifier(inst.get("executor"), acc, acceptance_role)

    kappa = inst.get("kappa")
    if isinstance(kappa, dict) and "risk" in kappa:
        prov = kappa.get("risk_provenance")
        if kappa["risk"] is None and prov != ABSENT_FROM_BENCHMARK:
            raise EpisodeInvalid(
                f"risk is null but provenance is {prov!r}; requires "
                f"{ABSENT_FROM_BENCHMARK!r} — an unmarked hole reads as data"
            )
        if kappa["risk"] is not None and prov == ABSENT_FROM_BENCHMARK:
            raise EpisodeInvalid("risk is filled but attributed to its own absence")
        if kappa["risk"] is not None and isinstance(prov, str) and "DLI-Bench" in prov:
            raise EpisodeInvalid(
                "risk attributed to DLI-Bench, which has no risk coordinate — a "
                "fabricated value wearing the benchmark's name"
            )

    loss = inst.get("loss")
    if isinstance(loss, dict):
        needed = ("value", "c_det", "c_undo", "c_residual", "rho", "p_star")
        if all(isinstance(loss.get(k), (int, float)) for k in needed):
            rho_expected = (
                loss["c_det"] + loss["c_undo"] + loss["c_residual"]
            ) / loss["value"]
            if abs(loss["rho"] - rho_expected) > _ROUNDING:
                raise EpisodeInvalid(
                    f"rho {loss['rho']} != (c_det+c_undo+c_residual)/value = "
                    f"{rho_expected}"
                )
            p_expected = loss["rho"] / (1.0 + loss["rho"])
            if abs(loss["p_star"] - p_expected) > _ROUNDING:
                raise EpisodeInvalid(
                    f"p_star {loss['p_star']} != rho/(1+rho) = {p_expected}"
                )

    root = None
    if isinstance(acc, dict) and isinstance(acc.get("root_criterion_declared_at"), str):
        root = parse_instant(acc["root_criterion_declared_at"])
    for i, iv in enumerate(inst.get("human_interventions") or []):
        if isinstance(iv, dict) and "t_delta" in iv:
            raise EpisodeInvalid(
                f"human_interventions[{i}]: t_delta is a stored literal; it must "
                "be computed by subtracting raised_at from responded_at"
            )
        if isinstance(iv, dict) and "raised_at" in iv and "responded_at" in iv:
            a = parse_instant(iv["raised_at"], "raised_at")
            b = parse_instant(iv["responded_at"], "responded_at")
            if b < a:
                raise EpisodeInvalid(
                    f"human_interventions[{i}]: responded_at precedes raised_at"
                )
            if root is not None and a < root:
                raise EpisodeInvalid(
                    f"human_interventions[{i}].raised_at: work began before the "
                    "root criterion was declared — the criterion was fitted to "
                    "the work"
                )
