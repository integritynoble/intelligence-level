"""Build identity strings stamped into every capabilities document.

These are the three provenance fields a downloaded binary carries so a stranger
can trace it back: what version, built from which lane commit, packaging which
upstream tier. ``TIER_SHA`` is the pinned ``dl-brain`` tier commit
``f3099a55…`` — the commit that actually carries ``tier.py``, the tier this lane
packages.

Provenance a reader cannot trust is decoration. F7 was that all three fields were
resolved from ``os.environ`` unconditionally, so ``DLI_BUILD_SHA=000…0`` forged
the value at exit 0 — a restraint keyed on a value the restrained party controls,
the F5/F6 defect class a third time. The fix is a two-source resolution:

* **Baked wins.** The build pipeline (``tools/gen_build_stamp.py``) *generates* a
  module ``dli_dist/_build_stamp.py`` holding the three values as **literals**,
  computed at build time from ``git rev-parse HEAD`` and the pinned tier SHA. When
  that stamp is present, it wins and the environment is **ignored entirely** — a
  forged ``DLI_BUILD_SHA`` changes nothing in ``--version`` or ``--capabilities``.
* **Env override survives only in a source checkout.** A plain checkout carries no
  stamp (it is git-ignored, generated at build), so the pipeline can still pin a
  value through the environment and tests can exercise a known one.

Nothing here reaches the network or imports anything but the stdlib.
"""

from __future__ import annotations

import importlib
import os

__all__ = ["VERSION", "BUILD_SHA", "TIER_SHA", "DIRTY", "BAKED"]

#: Honest source-checkout defaults. "unpinned-dev-build" is deliberate: a
#: fabricated hex here would be a false provenance claim before a build stamps a
#: real commit. TIER_SHA is the pinned dl-brain tier commit f3099a55 (plan0.md),
#: the commit that carries tier.py — a checkout with the tier vendored under
#: vendor/dl-brain-f3099a55/ resolves it from this default.
_DEFAULT_VERSION = "0.4.0-dev"
_DEFAULT_BUILD_SHA = "unpinned-dev-build"
_DEFAULT_TIER_SHA = "f3099a550da1ef5a7b2ca76ed07f97fdcfe57feb"

# The generated stamp is absent from the source tree by design (git-ignored). Its
# presence is the signal that these bytes came off a build, not a checkout.
try:
    _stamp = importlib.import_module("dli_dist._build_stamp")
except ImportError:
    _stamp = None

if _stamp is not None and getattr(_stamp, "BAKED", False):
    # Baked provenance WINS; the environment cannot forge it (F7). A downloader's
    # DLI_BUILD_SHA is silently inert here — the whole point.
    VERSION = _stamp.VERSION
    BUILD_SHA = _stamp.BUILD_SHA
    TIER_SHA = _stamp.TIER_SHA
    #: True when the working tree was dirty at stamp time. A build refuses to
    #: pretend a dirty tree is a clean SHA: it records the SHA *and* this flag, in
    #: the stamp and in MANIFEST.json, rather than stamping a clean-looking lie.
    DIRTY = bool(getattr(_stamp, "DIRTY", False))
    BAKED = True
else:
    # Source checkout: the environment override still applies, so the pipeline can
    # pin a value and a test can exercise the "env honoured" verdict.
    VERSION = os.environ.get("DLI_VERSION", _DEFAULT_VERSION)
    BUILD_SHA = os.environ.get("DLI_BUILD_SHA", _DEFAULT_BUILD_SHA)
    TIER_SHA = os.environ.get("DLI_TIER_SHA", _DEFAULT_TIER_SHA)
    DIRTY = False
    BAKED = False
