"""The three-verb CLI surface shared by all six binaries.

    dli-<name> --capabilities          # JSON self-description, validated before print
    dli-<name> exec --contract c.json   # run a contract, emit an episode record on stdout
    dli-<name> --version                # version, build SHA, tier SHA

Five of the six binaries are built: ``dli-dl0`` and ``dli-accept`` (DL0), and the
DL tier ``dli-dl1``/``dli-dl2``/``dli-dl3``, which bind ``dl-brain``'s vendored
tier behind this surface. ``dli-bench`` remains a stub — the only one — and every
verb of it exits non-zero saying so. A stub that silently did something would be
a lie in the competence model (RULING 2): a Claude measurement filed under
another executor's name teaches the model a fiction.

Stdlib only; nothing here imports a network or model client.
"""

from __future__ import annotations

import json
import sys
from typing import Any, Callable

from dli_dist import _build
from dli_dist.capabilities import (
    accept_capabilities,
    check_capabilities,
    dl0_capabilities,
)

__all__ = [
    "run",
    "REAL",
    "STUBS",
    "main_dl0",
    "main_dl1",
    "main_dl2",
    "main_dl3",
    "main_accept",
    "main_bench",
]

#: name -> (capabilities builder, exec entrypoint)
REAL: dict[str, tuple[Callable[[], dict], Callable[[list[str]], int]]] = {}

#: name -> the level the stub will eventually hold, for its stub message.
STUBS = {
    "dli-bench": "bench-runner",
}


def _register_real() -> None:
    # Imported lazily so `import dli_dist.dl0` stays cheap and stdlib-bare, and so
    # a broken sibling cannot stop an unrelated binary from starting.
    from dli_dist import accept, dl0, dl1, dl2, dl3
    from dli_dist.tier_capabilities import (
        dl1_capabilities,
        dl2_capabilities,
        dl3_capabilities,
    )

    REAL["dli-dl0"] = (dl0_capabilities, dl0._main)
    REAL["dli-accept"] = (accept_capabilities, accept._main)
    REAL["dli-dl1"] = (dl1_capabilities, dl1._main)
    REAL["dli-dl2"] = (dl2_capabilities, dl2._main)
    REAL["dli-dl3"] = (dl3_capabilities, dl3._main)


def _emit_capabilities(builder: Callable[[], dict]) -> int:
    doc = builder()
    # Validate our own output before printing it: a binary that emitted a
    # capabilities document its own schema rejects would be shipping a lie.
    check_capabilities(doc)
    json.dump(doc, sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")
    return 0


def _emit_version(name: str) -> int:
    json.dump(
        {
            "executor_id": name,
            "version": _build.VERSION,
            "build_sha": _build.BUILD_SHA,
            "tier_sha": _build.TIER_SHA,
        },
        sys.stdout,
        indent=2,
        sort_keys=True,
    )
    sys.stdout.write("\n")
    return 0


def _stub(name: str, level: str) -> int:
    sys.stderr.write(
        f"{name}: stub — not built in this phase. Phases 1-2 of lane dli/dl-dist "
        f"ship only dli-dl0 and dli-accept; {name} (would hold {level}) is a "
        "placeholder that intentionally does nothing and exits non-zero, so it "
        "cannot be mistaken for a working executor.\n"
    )
    return 70  # EX_SOFTWARE: named but not implemented.


def run(name: str, argv: list[str]) -> int:
    """Dispatch one binary's argv. Returns the process exit code.

    ``name`` is the binary name (e.g. ``dli-dl0``); ``argv`` excludes it.
    """
    if not argv:
        sys.stderr.write(
            f"usage: {name} [--capabilities | exec --contract c.json | --version]\n"
        )
        return 2

    verb = argv[0]

    # Stubs: the argument surface is present, every verb refuses.
    if name in STUBS:
        if verb in ("--capabilities", "exec", "--version"):
            return _stub(name, STUBS[name])
        sys.stderr.write(f"{name}: unknown verb {verb!r}\n")
        return 2

    _register_real()
    if name not in REAL:
        sys.stderr.write(f"unknown binary {name!r}\n")
        return 2
    builder, exec_main = REAL[name]

    if verb == "--capabilities":
        return _emit_capabilities(builder)
    if verb == "--version":
        return _emit_version(name)
    if verb == "exec":
        return exec_main(argv[1:])
    sys.stderr.write(f"{name}: unknown verb {verb!r}\n")
    return 2


# Console-script entry points for the wheel. setuptools calls these with no
# arguments and does ``sys.exit(fn())``, so each returns the process exit code.
# The binary name is fixed per entry point — argv[0] is not trusted to name the
# executor, so a renamed console script cannot masquerade as another binary.
def main_dl0() -> int:
    return run("dli-dl0", sys.argv[1:])


def main_dl1() -> int:
    return run("dli-dl1", sys.argv[1:])


def main_dl2() -> int:
    return run("dli-dl2", sys.argv[1:])


def main_dl3() -> int:
    return run("dli-dl3", sys.argv[1:])


def main_accept() -> int:
    return run("dli-accept", sys.argv[1:])


def main_bench() -> int:
    return run("dli-bench", sys.argv[1:])
