"""dli_dist — the distribution lane's packaged tier.

Stdlib only, by construction. ``python3 -I -c "import dli_dist.dl0"`` must succeed
on a bare Python with nothing third-party importable: whoever downloads a binary
from this lane gets a thing that runs, not a thing that first needs a wheel.
"""

__all__ = ["__version__"]

from dli_dist._build import VERSION as __version__
