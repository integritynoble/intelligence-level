"""dli-accept — acceptance checks that run at DL0.

RULING 2 requirement 3: *verification runs at DL0. Deterministic, no strategy,
nothing that can be argued with. A verifier that plans is a verifier that can be
persuaded.* So this module reads a **criterion** and an **artifact** and reports
the **comparison** — deterministically, from a closed set of check types, with no
planner and no model client.

The deliberate seam
-------------------
``dli-accept`` **measures**; it does not **judge**. The comparison outcome
(``equal`` / ``matches``) is a fact about two byte strings, written into the
evidence artifact for whoever accepts to read. The episode record it emits
carries **no verdict**: ``verification`` and ``result`` are null, exactly as for
``dli-dl0``. CRITERION.md is explicit that "verifier1:dl-acceptor says done, not
me" — this lane ships the deterministic instrument, not the ruling.

Consequently the process exit code reflects whether the *check ran*, not whether
the artifact *matched*: a completed comparison exits 0 whether or not the bytes
agree (the agreement is in the evidence). An unsupported criterion type is a
``specification`` failure and exits non-zero — the instrument could not run, and
that is a fact about the instrument, not a verdict about the artifact.

Stdlib only.
"""

from __future__ import annotations

import hashlib
import json
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dli_dist import episode, kappa
from dli_dist._record import ContractError, resolve_blocks

__all__ = ["CHECKS", "EXECUTOR_ID", "MAX_ARTIFACT_BYTES", "execute"]

EXECUTOR_ID = "dli-accept"

#: dli-accept is the one ACCEPTANCE-role binary in the lane: its whole job is to
#: judge an artifact it did not produce. This is why a record it emits may name
#: itself as its own verifier (an accept run IS its own verifier), and it is the
#: single source of truth for both the ``acceptance_role`` field of its
#: capabilities document and the role it hands ``episode.draft_episode``. The
#: distinct-subject requirement in ``locus`` still applies on top of this (F6):
#: role is necessary, not sufficient.
ACCEPTANCE_ROLE = True

#: The closed set of criterion types this verifier will evaluate.
CHECKS = frozenset({"sha256_equals", "bytes_equal"})

MAX_ARTIFACT_BYTES = 10 * 1024 * 1024


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _read_bytes(path: str) -> bytes:
    p = Path(path)
    if not p.is_file():
        raise ContractError(f"not a file: {path!r}", failure_class="tool_env")
    size = p.stat().st_size
    if size > MAX_ARTIFACT_BYTES:
        raise ContractError(
            f"{path!r} is {size} bytes, over the declared max {MAX_ARTIFACT_BYTES}"
        )
    return p.read_bytes()


def _check_sha256_equals(criterion: dict[str, Any], out: Path) -> tuple[list[str], dict]:
    artifact = criterion.get("artifact")
    expected = criterion.get("expected_sha256")
    if not isinstance(artifact, str) or not isinstance(expected, str):
        raise ContractError(
            "sha256_equals needs criterion.artifact and criterion.expected_sha256"
        )
    observed = hashlib.sha256(_read_bytes(artifact)).hexdigest()
    detail = {
        "check": "sha256_equals",
        "artifact": str(Path(artifact).resolve()),
        "expected_sha256": expected,
        "observed_sha256": observed,
        # A measurement, not a verdict about task success.
        "matches": observed == expected,
    }
    argv = ["accept:sha256_equals", str(Path(artifact).resolve()), f"expect={expected}"]
    return argv, detail


def _check_bytes_equal(criterion: dict[str, Any], out: Path) -> tuple[list[str], dict]:
    artifact = criterion.get("artifact")
    expected_file = criterion.get("expected_file")
    if not isinstance(artifact, str) or not isinstance(expected_file, str):
        raise ContractError(
            "bytes_equal needs criterion.artifact and criterion.expected_file"
        )
    a, b = _read_bytes(artifact), _read_bytes(expected_file)
    detail = {
        "check": "bytes_equal",
        "artifact": str(Path(artifact).resolve()),
        "expected_file": str(Path(expected_file).resolve()),
        "observed_sha256": hashlib.sha256(a).hexdigest(),
        "expected_sha256": hashlib.sha256(b).hexdigest(),
        "matches": a == b,
    }
    argv = ["accept:bytes_equal", str(Path(artifact).resolve()),
            str(Path(expected_file).resolve())]
    return argv, detail


_DISPATCH = {"sha256_equals": _check_sha256_equals, "bytes_equal": _check_bytes_equal}


def execute(contract: dict[str, Any]) -> dict[str, Any]:
    """Run the contract's one criterion check and return an episode record.

    The contract mirrors dl0's, with ``criterion`` in place of ``operation``/``args``::

        {"task_id","criterion":{"type", ...}, "kappa","kappa_provenance",
         "acceptance","loss", "predicted_band"?,"intervention_budget"?,"artifacts_dir"?}
    """
    if "task_id" not in contract:
        raise ContractError("contract missing required field 'task_id'")
    if "criterion" not in contract or not isinstance(contract["criterion"], dict):
        raise ContractError("contract missing required object field 'criterion'")
    task_id = contract["task_id"]
    criterion = contract["criterion"]
    check_type = criterion.get("type")

    blocks = resolve_blocks(contract)

    out = Path(contract.get("artifacts_dir") or tempfile.mkdtemp(prefix="dli-accept-"))
    out.mkdir(parents=True, exist_ok=True)

    started = _now()
    failure_class: str | None = None
    if check_type not in CHECKS:
        argv = ["accept:refused", str(check_type)]
        exit_code = 64
        failure_class = "specification"
        detail = {
            "check": check_type, "refused": True,
            "reason": f"criterion type {check_type!r} not in declared set {sorted(CHECKS)}",
        }
    else:
        argv, detail = _DISPATCH[check_type](criterion, out)
        exit_code = 0  # the instrument ran; 'matches' lives in the evidence.
    ended = _now()

    result_file = out / "acceptance_check.json"
    result_file.write_text(json.dumps(detail, indent=2, sort_keys=True), encoding="utf-8")

    run_record = {
        "executor_id": EXECUTOR_ID,
        "task_id": task_id,
        "argv": argv,
        "exit_code": exit_code,
        "started_at": started,
        "ended_at": ended,
        "comparison": detail,  # includes 'matches'/'equal' — a measurement, not a verdict
    }
    run_file = out / "execution_result.json"
    run_file.write_text(json.dumps(run_record, indent=2, sort_keys=True), encoding="utf-8")

    evidence = {"execution_result": str(run_file), "acceptance_check": str(result_file)}
    latency = (
        episode.parse_instant(ended) - episode.parse_instant(started)
    ).total_seconds()

    record = episode.draft_episode(
        task_id=task_id,
        task_band=contract.get("predicted_band", "T1"),
        kappa=blocks["kappa"],
        intervention_budget=contract.get("intervention_budget", "H0"),
        executor=EXECUTOR_ID,
        acceptance_role=ACCEPTANCE_ROLE,  # True: an accept run may verify a distinct subject.
        replans=0,
        latency_seconds=max(latency, 0.0),
        loss=blocks["loss"],
        acceptance=blocks["acceptance"],
        evidence=evidence,
        held_level="DL0",
        opened_level="DL0",
        failure_class=failure_class,
        executor_stub=False,
        compute_cost=0.0,
        benchmark_assets_present=False,
    )
    return {"record": record, "exit_code": exit_code}


def _main(argv: list[str]) -> int:
    contract_path = None
    it = iter(argv)
    for tok in it:
        if tok == "--contract":
            contract_path = next(it, None)
    if not contract_path:
        sys.stderr.write("usage: dli-accept exec --contract <c.json>\n")
        return 2
    try:
        contract = json.loads(Path(contract_path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        sys.stderr.write(f"could not read/parse contract {contract_path!r}: {exc}\n")
        return 2
    try:
        outcome = execute(contract)
    except kappa.KappaPermissionError as exc:
        # Distinct from a provenance failure: the row is real but outside the
        # set this lane may read (F2 / RULING 3 §4.4).
        sys.stderr.write(f"REFUSED (charter: unpermitted benchmark row): {exc}\n")
        return 5
    except kappa.KappaProvenanceError as exc:
        sys.stderr.write(f"REFUSED (kappa provenance): {exc}\n")
        return 3
    except ContractError as exc:
        sys.stderr.write(f"REFUSED ({exc.failure_class}): {exc}\n")
        return 3
    except episode.EpisodeInvalid as exc:
        sys.stderr.write(f"could not build a valid episode record: {exc}\n")
        return 4
    json.dump(outcome["record"], sys.stdout, ensure_ascii=False)
    sys.stdout.write("\n")
    return outcome["exit_code"]


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
