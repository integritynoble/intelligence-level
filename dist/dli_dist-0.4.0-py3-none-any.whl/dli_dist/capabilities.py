"""Capabilities documents: build them, validate them, and enforce the one rule
that gives the schema teeth.

The schema in ``schemas/capabilities.schema.json`` constrains the *shape* of a
capabilities document. The rule that matters is not a shape: **a level-DL0
executor may not require an LLM, the network, or credentials, and it may not
cost an LLM call or money per invocation.** RULING 2 requirement 1 is about
cost, not a boolean — a DL0 whose cost is indistinguishable from DL3's has been
named, not built. A document can set ``llm_required: false`` and still declare
seven ``llm_calls_per_invocation``; the structural schema (integer >= 0) waves
that through. JSON Schema cannot express "if level is DL0 then these booleans
are false and the cost model is zero", so it lives here, next to the schema, as
a derived check.

Run as a script to validate a document by real process exit code::

    python3 -m dli_dist.capabilities path/to/doc.json     # exit 0 valid, 1 invalid
    python3 -m dli_dist.capabilities --dl0                 # print the real DL0 doc

Stdlib only.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from dli_dist import _build, _resources
from dli_dist.jsonschema_lite import ValidationError, load_schema_text, validate

__all__ = [
    "CAPABILITIES_SCHEMA_PATH",
    "CapabilitiesError",
    "check_capabilities",
    "dl0_capabilities",
    "stub_capabilities",
]

#: The source-checkout location of the schema, kept for reference. The loader
#: below reads it via ``importlib.resources`` instead, so validity does not depend
#: on the working directory OR on the schema being a real filesystem file — a
#: zipapp holds it as a zip member (F8: the acceptance test is about the artifact).
CAPABILITIES_SCHEMA_PATH = (
    Path(__file__).resolve().parent.parent / "schemas" / "capabilities.schema.json"
)

_SCHEMA_CACHE: dict | None = None


def _capabilities_schema() -> dict:
    global _SCHEMA_CACHE
    if _SCHEMA_CACHE is None:
        _SCHEMA_CACHE = load_schema_text(
            _resources.schema_text(_resources.CAPABILITIES_SCHEMA)
        )
    return _SCHEMA_CACHE


class CapabilitiesError(Exception):
    """A capabilities document is invalid — structurally or by the DL0 rule."""


def check_capabilities(doc: Any, schema: dict | None = None) -> None:
    """Validate a capabilities document. Raise on the first violation.

    Two layers: the structural schema, then the cross-field DL0 rule. The DL0
    rule runs only after structure passes, so its error is never masked by a
    missing-field error.
    """
    if schema is None:
        schema = _capabilities_schema()
    try:
        validate(doc, schema)
    except ValidationError as exc:
        raise CapabilitiesError(f"structure: {exc}") from exc

    # The rule with teeth. Only reachable once structure holds, so `doc` is a
    # dict with the three booleans present and boolean-typed.
    if doc["level"] == "DL0":
        forbidden = [
            name
            for name in ("llm_required", "network_required", "credentials_required")
            if doc[name] is True
        ]
        if forbidden:
            raise CapabilitiesError(
                "level DL0 but "
                + ", ".join(f"{n}=true" for n in forbidden)
                + " — RULING 2 req 1: a DL0 whose cost is indistinguishable from "
                "DL3's has been named, not built"
            )
        if doc["plans"] is True:
            raise CapabilitiesError(
                "level DL0 but plans=true — a planner at DL0 is not a DL0 (RULING 2)"
            )
        # The cost model is what RULING 2 requirement 1 is actually about: *"A
        # DL0 step must not cost an LLM call."* A document can set the three
        # booleans false and still declare seven calls per invocation; the
        # structural schema (integer >= 0) waves that through. A DL0 whose cost
        # is indistinguishable from DL3's has been named, not built — so the
        # cost, not just the booleans, is checked here.
        cost = doc["cost_model"]
        calls = cost["llm_calls_per_invocation"]
        if calls != 0:
            raise CapabilitiesError(
                f"level DL0 but cost_model.llm_calls_per_invocation={calls} — "
                "RULING 2 req 1: a DL0 step must not cost an LLM call; a DL0 "
                "whose cost is indistinguishable from DL3's has been named, not built"
            )
        usd = cost["usd_per_invocation"]
        if usd is not None and usd > 0:
            raise CapabilitiesError(
                f"level DL0 but cost_model.usd_per_invocation={usd} — RULING 2 "
                "req 1: a DL0 invocation that costs money is not costless "
                "deterministic execution"
            )


def dl0_capabilities() -> dict[str, Any]:
    """The real DL0 capabilities document for ``dli-dl0``.

    The operation set here is the closed set ``dl0`` will attempt; anything else
    is a `specification` failure, not an attempt. Kept in sync with
    ``dli_dist.dl0.OPERATIONS`` by a test.
    """
    from dli_dist import dl0

    return {
        "level": "DL0",
        "plans": False,
        "llm_required": False,
        "network_required": False,
        "credentials_required": False,
        # A performer, never an acceptor — sourced from dl0 itself so this
        # document and the self-certification guard cannot disagree (F6).
        "acceptance_role": dl0.ACCEPTANCE_ROLE,
        "cost_model": {
            "llm_calls_per_invocation": 0,
            "unit": "usd",
            "usd_per_invocation": 0.0,
        },
        "declared_limits": {
            "operations": sorted(dl0.OPERATIONS),
            "max_artifact_bytes": dl0.MAX_ARTIFACT_BYTES,
            "notes": (
                "One declared operation per contract, executed deterministically. "
                "No planner, no model client, no retry strategy. An operation "
                "outside this set is a specification failure."
            ),
        },
        "version": _build.VERSION,
        "build_sha": _build.BUILD_SHA,
        "tier_sha": _build.TIER_SHA,
        "executor_id": "dli-dl0",
    }


def accept_capabilities() -> dict[str, Any]:
    """The real DL0 capabilities document for ``dli-accept``.

    Verification runs at DL0 (RULING 2 req 3): deterministic, no LLM, no network.
    The operation set is the closed set of criterion checks it evaluates.
    """
    from dli_dist import accept

    return {
        "level": "DL0",
        "plans": False,
        "llm_required": False,
        "network_required": False,
        "credentials_required": False,
        # The one acceptance-role binary: this is what admits an accept run naming
        # itself as verifier over a distinct subject (F6). Sourced from accept.
        "acceptance_role": accept.ACCEPTANCE_ROLE,
        "cost_model": {
            "llm_calls_per_invocation": 0,
            "unit": "usd",
            "usd_per_invocation": 0.0,
        },
        "declared_limits": {
            "operations": sorted(accept.CHECKS),
            "max_artifact_bytes": accept.MAX_ARTIFACT_BYTES,
            "notes": (
                "Deterministic acceptance checks at DL0: reads a criterion and an "
                "artifact and reports the comparison. It measures; it does not "
                "judge. No planner, no model client."
            ),
        },
        "version": _build.VERSION,
        "build_sha": _build.BUILD_SHA,
        "tier_sha": _build.TIER_SHA,
        "executor_id": "dli-accept",
    }


def stub_capabilities(level: str, executor_id: str) -> dict[str, Any]:
    """A capabilities document for a not-yet-built binary.

    Phase 1-2 ships only ``dli-dl0`` and ``dli-accept``. The stub binaries do not
    emit this from their CLI (they exit non-zero on every verb, saying they are
    stubs); this exists so tests can assert a stub's declared shape is honest —
    empty operation set, and the level it will eventually hold.
    """
    return {
        "level": level,
        "plans": level != "DL0",
        "llm_required": level in ("DL1", "DL2", "DL3", "DL4", "DL5"),
        "network_required": False,
        "credentials_required": False,
        # Every DLn executor and the bench runner are performers, not acceptors:
        # only dli-accept judges work it did not produce. A stub is never an
        # acceptance role, so a record it emits can never self-certify (F6).
        "acceptance_role": False,
        "cost_model": {
            "llm_calls_per_invocation": 0 if level == "DL0" else 1,
            "unit": "usd",
            "usd_per_invocation": None,
        },
        "declared_limits": {
            "operations": [],
            "max_artifact_bytes": None,
            "notes": "stub — not built in this phase",
        },
        "version": _build.VERSION,
        "build_sha": _build.BUILD_SHA,
        "tier_sha": _build.TIER_SHA,
        "executor_id": executor_id,
    }


def _main(argv: list[str]) -> int:
    if not argv or argv[0] in ("-h", "--help"):
        sys.stderr.write(
            "usage: python3 -m dli_dist.capabilities <doc.json>   # validate\n"
            "       python3 -m dli_dist.capabilities --dl0         # print DL0 doc\n"
        )
        return 2
    if argv[0] == "--dl0":
        json.dump(dl0_capabilities(), sys.stdout, indent=2, sort_keys=True)
        sys.stdout.write("\n")
        return 0
    path = argv[0]
    try:
        doc = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        sys.stderr.write(f"could not read/parse {path!r}: {exc}\n")
        return 2
    try:
        check_capabilities(doc)
    except CapabilitiesError as exc:
        sys.stderr.write(f"INVALID: {exc}\n")
        return 1
    sys.stderr.write("VALID\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
