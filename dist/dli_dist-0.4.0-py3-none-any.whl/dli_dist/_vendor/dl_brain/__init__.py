"""dl-brain — the reference chassis for the delegation federation.

The brain plans. It never executes and it never accepts.

Stdlib only, by decision recorded in BASELINE.md.
"""

__all__ = ["BRAIN_IDENTITY"]

#: The brain's own identity. Gate G2 asserts the verifier is *not* this string.
BRAIN_IDENTITY = "dl-brain"
