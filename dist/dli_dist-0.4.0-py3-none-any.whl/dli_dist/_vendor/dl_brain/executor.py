"""The Executor protocol — the shared artifact.

Five other lanes fork this module. Everything here is chosen for what it makes
*impossible*, not for what it makes convenient.

The one design decision that matters
------------------------------------
``ExecutionResult`` has no ``success`` field, and no ``verification`` field, and
no ``result`` field. An executor reports **what it did**: the argv it ran, the
exit code it got, the artifacts it left, the clock it burned. It never reports
whether that was good enough.

This is the plan's evidence bus --- *"artifacts + traces, never claims"* --- made
structural. If ``ExecutionResult`` carried ``success: bool``, then the party that
performed the work would be the party that judged it, every adapter author would
fill it in, and the whole acceptance separation would be one convenient boolean
away from collapsing. There is nowhere in this dataclass to put a verdict, so
nobody puts one there.

Stdlib only. A contract that needs a wheel installed is a contract with a hidden
precondition, and five accounts would inherit it.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, Sequence, runtime_checkable

__all__ = [
    "FailureClass",
    "DEMOTING_FAILURES",
    "ExecutionResult",
    "Executor",
    "StubExecutorError",
    "VerdictWriteRefused",
]


class FailureClass(enum.Enum):
    """The six-way taxonomy (plan section 6).

    The taxonomy exists to answer exactly one question: *does this failure mean
    the agent's frontier is lower than we thought?* Five of the six say no.

    A system that demotes on a flaky tool has measured its tooling, not its
    intelligence.
    """

    SPECIFICATION = "specification"  # the contract was wrong -> rewrite it
    PLANNING = "planning"            # the decomposition was wrong -> replan
    EXECUTION = "execution"          # the motor stumbled -> retry or reroute
    TOOL_ENV = "tool_env"            # the world was broken -> observe, wait, escalate
    VERIFICATION = "verification"    # the judge was inadequate -> stronger verifier
    CAPABILITY = "capability"        # the agent could not -> DEMOTE

    @property
    def demotes(self) -> bool:
        return self is FailureClass.CAPABILITY


#: The whole point of the taxonomy, as a set. Exactly one member.
DEMOTING_FAILURES = frozenset(f for f in FailureClass if f.demotes)


class StubExecutorError(RuntimeError):
    """Raised by an adapter whose binary is not installed.

    Hermes and Pi are not installed on any account on this machine. Their
    adapters exist so the protocol is proven vendor-neutral, and they raise
    rather than return.

    An adapter that silently fell back to Claude would not be a convenience; it
    would put a Claude measurement into the competence model under another
    agent's name, and ``AgentCompetenceModel`` would then be learning a fiction.
    A stub must say it is a stub.
    """


class VerdictWriteRefused(RuntimeError):
    """Raised when anything inside the brain tries to author a verdict.

    Gate G5 of ``CRITERION.md``. The brain plans and never accepts; this is the
    exception that makes "never" enforceable rather than aspirational.
    """


@dataclass(frozen=True)
class ExecutionResult:
    """What an executor is permitted to say.

    Note what is absent: no ``success``, no ``passed``, no ``verification``, no
    ``result``. See the module docstring.

    ``failure_class`` is not a verdict --- it is a *diagnosis of the run*, and it
    is only meaningful when ``exit_code != 0``. The brain uses it to decide
    whether to rewrite, replan, retry, wait, strengthen the judge, or demote. It
    never decides whether the task was completed.
    """

    task_id: str
    executor_id: str
    argv: Sequence[str]
    exit_code: int
    started_at: str          # UTC instant, ISO-8601 with trailing Z
    ended_at: str            # UTC instant, ISO-8601 with trailing Z
    artifacts: Mapping[str, str] = field(default_factory=dict)  # name -> abs path
    stdout_path: str | None = None
    stderr_path: str | None = None
    replans: int = 0
    failure_class: FailureClass | None = None
    compute_cost_usd: float | None = None
    trace: Sequence[Mapping[str, Any]] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if self.failure_class is not None and self.exit_code == 0:
            raise ValueError(
                "failure_class set on a run that exited 0 — a failure class "
                "diagnoses a failure, and exit 0 is not one"
            )

    @property
    def ran_clean(self) -> bool:
        """The process exited 0.

        Deliberately *not* named ``success``. It means the motor did not crash.
        It says nothing whatever about whether the task was accomplished, and a
        caller that treats it as a verdict has reintroduced the thing this
        module exists to prevent.
        """
        return self.exit_code == 0


@runtime_checkable
class Executor(Protocol):
    """One interface, many adapters.

    Three methods, because three questions get asked: what can you do, do it,
    and are you alive.
    """

    def capabilities(self) -> dict:
        """Static self-description.

        Required keys:
          ``executor_id``  str   — stable identity, recorded in every episode
          ``stub``         bool  — True when no binary backs this adapter
          ``model``        str|None
          ``authority``    dict  — what this adapter can be granted at most

        ``stub`` is required rather than optional so that a competence model can
        refuse to learn from an adapter that never ran anything.
        """
        ...

    def execute(self, contract) -> ExecutionResult:
        """Run the contract. Return evidence. Never return a verdict."""
        ...

    def status(self) -> dict:
        """Liveness. Required key ``available: bool``.

        Must be answerable without running a task, and must distinguish
        *absent* from *present-but-failing* — a watcher that collapses those two
        will report a dead motor as merely idle.
        """
        ...
