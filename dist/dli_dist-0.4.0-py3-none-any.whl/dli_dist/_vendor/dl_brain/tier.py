"""The DL tier — DL0..DL3 as levels behind one protocol.

RULING 2 cut executors along **vendor** (``claude_code.py``, ``codex.py``). This
module cuts them along **level**, and it goes *behind*
``dl_brain.executor.Executor``: ``capabilities()`` / ``execute(contract)`` /
``status()`` are unchanged, and nothing here may return a verdict.

What separates the levels is not the label
------------------------------------------
It is **what the contract supplies and what the executor must construct**:

===== ============================= ======================= ============ =======
level contract supplies             executor constructs     model calls  replans
===== ============================= ======================= ============ =======
DL0   the exact operation           nothing                 0            no
DL1   goal + the known procedure    the bound call sequence <= 1/param   no
DL2   the task, multi-step          plan, tool choice,      several      no
                                    state, recovery
DL3   outcome + constraints only    the strategy itself     several      **yes**
===== ============================= ======================= ============ =======

So the **shape of the contract** names the level it needs. ``classify`` is that
mechanism, and everything else in this module hangs off it:

* ``route`` is ``classify`` — the cheapest tier that holds, never a stronger one
  (§5.5 requirement 2).
* ``admits`` is the same comparison from the executor's side, and it is what
  makes a declared limit *enforced*: an executor handed a contract shaped above
  its own level refuses, structurally, **before the model client is touched**.
  An executor that calls a model in order to decide to refuse has *attempted*
  the contract; a refusal has to be free.

``plans`` is defined once, here, because the word is otherwise arguable:
**``plans`` is true iff the executor constructs a decomposition the contract did
not supply.** DL1 receives its decomposition (the procedure) and only *binds*
it, so DL1 is ``plans: false`` and leaves a ``call_sequence`` artifact, never a
plan. DL2 and DL3 construct theirs, so they are ``plans: true`` and leave a
``plan`` artifact. The declaration is checked against that behaviour, not
against its own string.

Failure comes from the world
----------------------------
The operations are the same deterministic primitives DL0 uses — hash a file,
compare bytes. A step fails because a path does not exist, never because a model
client said so. Recovery driven by a scripted response would measure the script.

Stdlib only, and this module imports nothing from ``dli_dist``: five lanes fork
it the way they forked ``executor.py``, and a contract that needs a wheel
installed is a contract with a hidden precondition.
"""

from __future__ import annotations

import hashlib
import json
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence, runtime_checkable

from dl_brain.executor import ExecutionResult, Executor, FailureClass

__all__ = [
    "DL_TIER_LEVELS",
    "OPERATIONS",
    "MAX_ARTIFACT_BYTES",
    "MAX_REPLANS",
    "MAX_RECOVERIES",
    "UNBOUND",
    "ContractShapeError",
    "ModelClient",
    "rank",
    "classify",
    "route",
    "admits",
    "executor_for",
    "DL0Executor",
    "DL1Executor",
    "DL2Executor",
    "DL3Executor",
]

#: The tier, in cost order. ``rank`` is the index, so the whole ordering
#: mechanism is one tuple and cannot drift between callers.
DL_TIER_LEVELS: tuple[str, ...] = ("DL0", "DL1", "DL2", "DL3")

#: The closed set of operations any level in this module will attempt. The tier
#: adds *control flow* over DL0's primitives; it does not add primitives. An
#: operation outside this set is a refusal, not an improvised attempt.
OPERATIONS = frozenset({"hash_file", "compare_bytes"})

#: Cap on bytes read into memory for a hash/compare, mirroring DL0's, so a
#: contract cannot turn a deterministic op into an unbounded one.
MAX_ARTIFACT_BYTES = 10 * 1024 * 1024

#: DL3's declared replan budget. Declared, so "up to" is a number a reader can
#: check against ``ExecutionResult.replans`` rather than a promise.
MAX_REPLANS = 2

#: DL2's declared repair budget: one ``recover`` call and one retry, *within*
#: the plan. Replanning is the DL3 discriminator and DL2 never does it.
MAX_RECOVERIES = 1

#: The marker a DL1 procedure uses for a parameter it did not bind.
UNBOUND = "?"

# Exit codes. A refusal and a broken world are different non-zero things, and a
# caller that cannot tell them apart cannot decide whether to rewrite or wait.
EXIT_OK = 0
EXIT_SPECIFICATION = 64   # EX_USAGE-ish: the contract was wrong -> rewrite it
EXIT_PLANNING = 70        # the decomposition was wrong -> replan
EXIT_TOOL_ENV = 74        # EX_IOERR: the world was broken -> observe, escalate
EXIT_EXECUTION = 75       # the motor stumbled -> retry or reroute

_EXIT_FOR_FAILURE = {
    FailureClass.SPECIFICATION: EXIT_SPECIFICATION,
    FailureClass.PLANNING: EXIT_PLANNING,
    FailureClass.TOOL_ENV: EXIT_TOOL_ENV,
    FailureClass.EXECUTION: EXIT_EXECUTION,
}


class ContractShapeError(ValueError):
    """The contract supplies nothing that names a level.

    Not the same as "above my level". A contract with no ``operation``, no
    ``procedure``, no ``task`` and no ``outcome``+``constraints`` does not
    describe work at any tier, so there is no cheapest tier that holds it.
    """


@runtime_checkable
class ModelClient(Protocol):
    """The one thing a level above DL0 is allowed to reach for.

    Injected, never constructed here: an executor that builds its own client
    decides its own cost, and the cost is the axis the tier is measured on.
    ``purpose`` is not decoration — it is what makes a call countable by kind, so
    "DL2 makes one plan call and one tool call per step" is an assertion about
    the trace rather than a sentence in a docstring.
    """

    def complete(self, prompt: str, *, purpose: str) -> str: ...


# --- classification: the whole mechanism -------------------------------------


def rank(level: str) -> int:
    """Index of ``level`` in :data:`DL_TIER_LEVELS`. ``ValueError`` if unknown."""
    try:
        return DL_TIER_LEVELS.index(level)
    except ValueError:
        raise ValueError(
            f"unknown DL level {level!r}; known levels are {list(DL_TIER_LEVELS)}"
        ) from None


def classify(contract: Mapping[str, Any]) -> str:
    """The **minimum** level the contract's shape requires.

    Decided on what the contract *supplies*, most concrete first. A contract that
    hands over the exact operation needs nothing constructed, so it is DL0 no
    matter how it is labelled elsewhere — the label is not evidence, the shape is.
    """
    if not isinstance(contract, Mapping):
        raise ContractShapeError(
            f"contract is {type(contract).__name__}, not a mapping; nothing to classify"
        )
    if "operation" in contract:
        return "DL0"
    procedure = contract.get("procedure")
    if isinstance(procedure, (list, tuple)) and procedure:
        return "DL1"
    if "task" in contract:
        return "DL2"
    if "outcome" in contract and "constraints" in contract:
        return "DL3"
    raise ContractShapeError(
        "contract supplies no operation, no non-empty procedure, no task, and no "
        "outcome+constraints — it names no level, so no tier holds it"
    )


def route(contract: Mapping[str, Any]) -> str:
    """The cheapest tier that holds this contract (§5.5 requirement 2).

    Identical to :func:`classify` by construction, and that is the point:
    routing that could return something other than the minimum would be a second
    policy able to disagree with the first. Escalation on failure is the ratchet
    running the other way; it is not licence to open high.
    """
    return classify(contract)


def admits(level: str, contract: Mapping[str, Any]) -> bool:
    """Whether an executor at ``level`` may attempt ``contract``.

    ``rank(level) >= rank(classify(contract))``. A contract that classifies at no
    level is admitted by none: ``False`` rather than a raise, so the caller's
    refusal path is one branch and cannot be forgotten for the odd shape.
    """
    rank(level)  # unknown level is a programming error, not a False
    try:
        needed = classify(contract)
    except ContractShapeError:
        return False
    return rank(level) >= rank(needed)


# --- the deterministic primitives (the same ones DL0 runs) -------------------


class OperationFailure(Exception):
    """One operation did not complete, with the diagnosis of *why*.

    ``failure_class`` is a diagnosis of the run, never a verdict about the task.
    """

    def __init__(self, message: str, failure_class: FailureClass) -> None:
        super().__init__(message)
        self.failure_class = failure_class


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _read_bytes(path: str) -> bytes:
    p = Path(path)
    if not p.is_file():
        # The world refused. This is the failure the task family is built around:
        # a path that does not exist drives DL2's recovery and DL3's replans, so
        # neither is a number the scripted client chose.
        raise OperationFailure(f"not a file: {path!r}", FailureClass.TOOL_ENV)
    size = p.stat().st_size
    if size > MAX_ARTIFACT_BYTES:
        raise OperationFailure(
            f"{path!r} is {size} bytes, over the declared max {MAX_ARTIFACT_BYTES}",
            FailureClass.SPECIFICATION,
        )
    return p.read_bytes()


def _write_json(path: Path, payload: Any) -> str:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return str(path)


def _op_hash_file(args: Mapping[str, Any], out: Path, tag: str) -> tuple[list[str], dict, dict]:
    path = args.get("path")
    if not isinstance(path, str):
        raise OperationFailure("hash_file needs args.path (a string)", FailureClass.SPECIFICATION)
    algo = args.get("algo", "sha256")
    if algo not in hashlib.algorithms_guaranteed:
        raise OperationFailure(f"unsupported hash algo {algo!r}", FailureClass.SPECIFICATION)
    data = _read_bytes(path)
    detail = {
        "operation": "hash_file",
        "path": str(Path(path).resolve()),
        "algo": algo,
        "digest": hashlib.new(algo, data).hexdigest(),
        "bytes": len(data),
    }
    result = _write_json(out / f"{tag}.hash_file.result.json", detail)
    argv = ["dl-brain:hash_file", f"algo={algo}", str(Path(path).resolve())]
    return argv, {f"{tag}_hash_result": result}, detail


def _op_compare_bytes(args: Mapping[str, Any], out: Path, tag: str) -> tuple[list[str], dict, dict]:
    a, b = args.get("path_a"), args.get("path_b")
    if not isinstance(a, str) or not isinstance(b, str):
        raise OperationFailure(
            "compare_bytes needs args.path_a and args.path_b (strings)",
            FailureClass.SPECIFICATION,
        )
    da, db = _read_bytes(a), _read_bytes(b)
    detail = {
        "operation": "compare_bytes",
        "path_a": str(Path(a).resolve()),
        "path_b": str(Path(b).resolve()),
        "sha256_a": hashlib.sha256(da).hexdigest(),
        "sha256_b": hashlib.sha256(db).hexdigest(),
        # A measurement of two byte strings, NOT a verdict about a task.
        "equal": da == db,
    }
    result = _write_json(out / f"{tag}.compare_bytes.result.json", detail)
    argv = ["dl-brain:compare_bytes", str(Path(a).resolve()), str(Path(b).resolve())]
    return argv, {f"{tag}_compare_result": result}, detail


_DISPATCH = {"hash_file": _op_hash_file, "compare_bytes": _op_compare_bytes}

#: What each operation needs before it can be run at all. Used for two things:
#: running a step, and deciding whether a tool the model *chose* is admissible
#: for the step it was chosen for. The argument shape decides, so a client that
#: answers "hash_file" to every question cannot turn a comparison into a hash.
_REQUIRED_ARGS = {"hash_file": ("path",), "compare_bytes": ("path_a", "path_b")}


def _admissible(operation: str, args: Mapping[str, Any]) -> bool:
    if operation not in _REQUIRED_ARGS:
        return False
    return all(isinstance(args.get(k), str) for k in _REQUIRED_ARGS[operation])


def _run_operation(step: Mapping[str, Any], out: Path, tag: str) -> tuple[list[str], dict, dict]:
    operation = step.get("operation")
    args = dict(step.get("args") or {})
    if operation not in OPERATIONS:
        raise OperationFailure(
            f"operation {operation!r} not in declared set {sorted(OPERATIONS)}",
            FailureClass.SPECIFICATION,
        )
    return _DISPATCH[operation](args, out, tag)


# --- the executors -----------------------------------------------------------


class _TierExecutor:
    """Shared machinery. What differs between the levels is declared, not coded.

    Each subclass sets ``LEVEL``, ``PLANS``, and its budgets, and inherits one
    ``execute`` whose first act is the structural refusal. Every level can run a
    contract *at or below* itself, and it runs it the way that level's own shape
    demands — a DL3 handed a DL0 operation executes one operation and spends
    nothing. Routing down inside the executor is the same rule as routing down
    outside it (§5.5 requirement 2), so the two cannot disagree.
    """

    LEVEL = "DL0"
    PLANS = False
    NEEDS_CLIENT = False
    MAX_REPLANS = 0
    MAX_RECOVERIES = 0
    _DEFAULT_ID = "dl-brain:dl0"

    def __init__(
        self,
        *,
        model_client: ModelClient | None = None,
        executor_id: str | None = None,
        artifacts_dir: str | None = None,
    ) -> None:
        if self.NEEDS_CLIENT and model_client is None:
            raise ValueError(
                f"{type(self).__name__} requires a model_client by injection: "
                f"{self.LEVEL} constructs what the contract did not supply, and an "
                "executor that builds its own client decides its own cost"
            )
        self._client = model_client
        self.executor_id = executor_id or self._DEFAULT_ID
        self._artifacts_dir = artifacts_dir

    # -- protocol ------------------------------------------------------------

    def capabilities(self) -> dict:
        return {
            "executor_id": self.executor_id,
            "stub": False,
            # Not "claude-something": no model credential exists on this account,
            # so the only honest answer is whatever the injected client says it
            # is, and None when it says nothing.
            "model": getattr(self._client, "model", None),
            "authority": {
                "operations": sorted(OPERATIONS),
                "max_artifact_bytes": MAX_ARTIFACT_BYTES,
                "network": False,
                "writes_verdicts": False,
            },
            "level": self.LEVEL,
            "plans": self.PLANS,
            "llm_required": self.NEEDS_CLIENT,
            "max_replans": self.MAX_REPLANS,
            "max_recoveries": self.MAX_RECOVERIES,
            "admits_levels": [l for l in DL_TIER_LEVELS if rank(l) <= rank(self.LEVEL)],
        }

    def status(self) -> dict:
        """Answerable without running a task, and never by calling the model.

        *Absent* and *present-but-failing* are kept apart: a watcher that
        collapses them reports a dead motor as merely idle.
        """
        if self.NEEDS_CLIENT and self._client is None:
            return {"available": False, "reason": "no model client injected", "detail": "absent"}
        return {
            "available": True,
            "detail": "present",
            "model_client": type(self._client).__name__ if self._client is not None else None,
        }

    def execute(self, contract) -> ExecutionResult:
        """Run the contract. Return evidence. Never return a verdict."""
        started = _now()
        mapping = contract if isinstance(contract, Mapping) else {}
        task_id = str(mapping.get("task_id", "unknown"))
        out = self._out_dir(mapping)

        # --- the refusal, first, before anything else. -----------------------
        # Nothing above this line touches self._client, and that is the whole
        # content of T2: a refusal must be structural and free.
        try:
            needed = classify(contract)
        except ContractShapeError as exc:
            return self._refuse(task_id, out, started, needed=None, reason=str(exc))
        if rank(needed) > rank(self.LEVEL):
            return self._refuse(
                task_id, out, started, needed=needed,
                reason=(
                    f"contract is shaped for {needed}; this executor holds "
                    f"{self.LEVEL}. Declaring a limit and then attempting past it "
                    "would make the limit advisory"
                ),
            )

        trace: list[dict[str, Any]] = []
        runner = {
            "DL0": self._run_dl0,
            "DL1": self._run_dl1,
            "DL2": self._run_dl2,
            "DL3": self._run_dl3,
        }[needed]
        outcome = runner(mapping, out, trace)
        ended = _now()

        artifacts = dict(outcome["artifacts"])
        run_record = {
            "executor_id": self.executor_id,
            "held_level": self.LEVEL,
            "contract_level": needed,
            "task_id": task_id,
            "argv": outcome["argv"],
            "exit_code": outcome["exit_code"],
            "started_at": started,
            "ended_at": ended,
            "replans": outcome["replans"],
            "model_calls": sum(1 for e in trace if e.get("kind") == "model_call"),
            "artifacts": artifacts,
            "trace": trace,
        }
        artifacts["execution_result"] = _write_json(out / "execution_result.json", run_record)

        return ExecutionResult(
            task_id=task_id,
            executor_id=self.executor_id,
            argv=tuple(outcome["argv"]),
            exit_code=outcome["exit_code"],
            started_at=started,
            ended_at=ended,
            artifacts=artifacts,
            replans=outcome["replans"],
            failure_class=outcome["failure_class"],
            # UNMEASURED, not zero: no model credential exists on this account, so
            # no run here was billed. `None` is this codebase's idiom for
            # unmeasured; 0.0 would be a claim. DL0 overrides it, because a level
            # that structurally cannot call a model really does cost nothing.
            compute_cost_usd=self._compute_cost(trace),
            trace=tuple(trace),
        )

    # -- internals -----------------------------------------------------------

    def _compute_cost(self, trace: Sequence[Mapping[str, Any]]) -> float | None:
        return None

    def _out_dir(self, contract: Mapping[str, Any]) -> Path:
        base = contract.get("artifacts_dir") or self._artifacts_dir
        out = Path(base) if base else Path(
            tempfile.mkdtemp(prefix=f"dli-{self.LEVEL.lower()}-")
        )
        out.mkdir(parents=True, exist_ok=True)
        return out

    def _refuse(
        self, task_id: str, out: Path, started: str, *, needed: str | None, reason: str
    ) -> ExecutionResult:
        detail = {
            "refused": True,
            "executor_id": self.executor_id,
            "held_level": self.LEVEL,
            "contract_level": needed,
            "reason": reason,
            "model_calls": 0,
            "note": (
                "Refused on the contract's shape alone. No model client was "
                "consulted: an executor that calls a model in order to decide to "
                "refuse has attempted the contract."
            ),
        }
        path = _write_json(out / "specification_refusal.json", detail)
        return ExecutionResult(
            task_id=task_id,
            executor_id=self.executor_id,
            argv=(f"{self.executor_id}:refused", str(needed)),
            exit_code=EXIT_SPECIFICATION,
            started_at=started,
            ended_at=_now(),
            artifacts={"specification_refusal": path},
            replans=0,
            failure_class=FailureClass.SPECIFICATION,
            compute_cost_usd=0.0,  # measured: a refusal really does cost nothing.
            trace=(),
        )

    def _call(self, purpose: str, prompt: str, trace: list[dict[str, Any]]) -> str:
        if self._client is None:
            raise RuntimeError(
                f"{self.LEVEL} reached for a model client it was not given — this "
                "path should be unreachable; the constructor refuses a missing client"
            )
        reply = self._client.complete(prompt, purpose=purpose)
        trace.append({"kind": "model_call", "purpose": purpose, "reply": reply})
        return reply

    def _above_my_level(self, level: str) -> None:
        raise RuntimeError(
            f"{type(self).__name__} was asked to run a {level}-shaped contract, "
            "which admits() should already have refused"
        )

    # -- the four ways to run a contract -------------------------------------

    def _execute_steps(
        self,
        steps: Sequence[Mapping[str, Any]],
        out: Path,
        trace: list[dict[str, Any]],
        *,
        tag: str,
        recoveries: int = 0,
        constructed: bool = False,
    ) -> tuple[bool, list[str], dict, FailureClass | None]:
        """Run bound steps in order. Returns ``(ok, argv, artifacts, failure)``.

        ``recoveries`` is the *whole run's* repair budget: one ``recover`` call
        and one retry of the step that failed, and it is DL2's, not DL3's. When
        it is spent, the run stops — a motor that retried forever would report
        the world's failure as its own patience.

        ``constructed`` re-diagnoses one case honestly: when the executor (not
        the contract) chose the step, a step that is malformed is a *planning*
        failure, not a *specification* one. The contract cannot be blamed for a
        decomposition it did not supply.
        """
        argv: list[str] = []
        artifacts: dict[str, str] = {}
        budget = recoveries
        for i, step in enumerate(steps, start=1):
            attempt = 0
            while True:
                stag = f"{tag}{i}" if attempt == 0 else f"{tag}{i}r{attempt}"
                try:
                    step_argv, step_arts, detail = _run_operation(step, out, stag)
                except OperationFailure as exc:
                    failure = exc.failure_class
                    if constructed and failure is FailureClass.SPECIFICATION:
                        failure = FailureClass.PLANNING
                    trace.append({
                        "kind": "operation", "step": i, "attempt": attempt,
                        "operation": step.get("operation"), "ok": False,
                        "error": str(exc), "failure_class": failure.value,
                    })
                    if budget > 0:
                        budget -= 1
                        attempt += 1
                        # Repair *within* the plan: one call, one retry. The step
                        # is re-run unchanged, because what failed was the world.
                        self._call(
                            "recover",
                            f"step {i} ({step.get('operation')}) failed: {exc}. "
                            "Repair within the existing plan; do not replan.",
                            trace,
                        )
                        continue
                    return False, argv, artifacts, failure
                argv.extend(step_argv)
                artifacts.update(step_arts)
                trace.append({
                    "kind": "operation", "step": i, "attempt": attempt,
                    "operation": step.get("operation"), "ok": True,
                    "detail_keys": sorted(detail),
                })
                break
        return True, argv, artifacts, None

    def _run_dl0(self, contract, out, trace) -> dict[str, Any]:
        """The exact operation, executed. Nothing is constructed and nothing is asked."""
        operation = contract.get("operation")
        if operation not in OPERATIONS:
            path = _write_json(out / "specification_refusal.json", {
                "refused": True,
                "operation": operation,
                "reason": f"operation {operation!r} not in declared set {sorted(OPERATIONS)}",
                "note": "A closed set is a limit only if what is outside it is refused.",
            })
            return {
                "argv": [f"{self.executor_id}:refused", str(operation)],
                "exit_code": EXIT_SPECIFICATION,
                "artifacts": {"specification_refusal": path},
                "failure_class": FailureClass.SPECIFICATION,
                "replans": 0,
            }
        step = {"operation": operation, "args": dict(contract.get("args") or {})}
        ok, argv, artifacts, failure = self._execute_steps([step], out, trace, tag="op")
        return {
            "argv": argv or [f"{self.executor_id}:{operation}"],
            "exit_code": EXIT_OK if ok else _EXIT_FOR_FAILURE[failure],
            "artifacts": artifacts,
            "failure_class": None if ok else failure,
            "replans": 0,
        }

    def _run_dl1(self, contract, out, trace) -> dict[str, Any]:
        """Goal + the known procedure: bind it, run it, construct nothing.

        One ``bind_parameter`` call per unbound parameter and **none** when the
        procedure arrives fully bound — which is why the cost claim is asserted
        over a family carrying both kinds and not over one member.
        """
        procedure = [dict(s) for s in (contract.get("procedure") or [])]
        goal = contract.get("goal", "")
        bound: list[dict[str, Any]] = []
        bindings: list[dict[str, Any]] = []
        for i, step in enumerate(procedure, start=1):
            args = dict(step.get("args") or {})
            for key in sorted(args):
                if args[key] != UNBOUND:
                    continue
                value = self._call(
                    "bind_parameter",
                    f"goal: {goal}\nstep {i}: {step.get('operation')}\n"
                    f"bind parameter {key!r}; reply with the value alone.",
                    trace,
                )
                args[key] = value.strip()
                bindings.append({"step": i, "parameter": key, "bound_to": args[key]})
            bound.append({"operation": step.get("operation"), "args": args})

        # NOT a plan artifact, and the key does not say "plan": the decomposition
        # was supplied by the contract. DL1 bound it. `plans` is false and this
        # file is what makes that checkable rather than declared.
        artifacts = {"call_sequence": _write_json(out / "call_sequence.json", {
            "goal": goal,
            "supplied_procedure": procedure,
            "bound_call_sequence": bound,
            "bindings": bindings,
            "constructed_decomposition": False,
            "note": (
                "The contract supplied this decomposition. DL1 bound its unbound "
                "parameters and ran it: no plan was constructed, so `plans` is false."
            ),
        })}
        ok, argv, arts, failure = self._execute_steps(
            bound, out, trace, tag="s", recoveries=0, constructed=bool(bindings),
        )
        artifacts.update(arts)
        return {
            "argv": argv or [f"{self.executor_id}:no-steps"],
            "exit_code": EXIT_OK if ok else _EXIT_FOR_FAILURE[failure],
            "artifacts": artifacts,
            "failure_class": None if ok else failure,
            "replans": 0,  # DL1 does not replan. It has nothing to replan.
        }

    def _plan(
        self,
        out: Path,
        trace: list[dict[str, Any]],
        *,
        purpose: str,
        brief: str,
        inputs: Mapping[str, Any],
        strategy: str | None,
    ) -> tuple[list[dict[str, Any]], str]:
        """One planning call, then one ``choose_tool`` call per planned step.

        The tool the client names is *validated against the step's arguments*
        before it is used. That is not distrust of the client — it is what stops
        a client that answers ``hash_file`` to everything from turning a
        comparison into a hash, which would make the level's behaviour a property
        of the script rather than of the level.
        """
        approach = self._call(
            purpose,
            f"{brief}\ninputs: {sorted(inputs)}\n"
            + (f"strategy: {strategy}\n" if strategy else "")
            + "name the approach.",
            trace,
        ).strip()
        steps = _decompose(inputs)
        for i, step in enumerate(steps, start=1):
            chosen = self._call(
                "choose_tool",
                f"approach: {approach}\nstep {i}: {step['why']}\n"
                f"available tools: {sorted(OPERATIONS)}; name one.",
                trace,
            ).strip()
            if chosen in OPERATIONS and _admissible(chosen, step["args"]):
                step["operation"] = chosen
                step["tool_choice"] = chosen
            else:
                step["tool_choice_rejected"] = chosen
                step["tool_choice_rejected_because"] = (
                    f"{chosen!r} cannot run against this step's arguments "
                    f"({sorted(step['args'])}); kept {step['operation']!r}"
                )
        return steps, approach

    def _run_dl2(self, contract, out, trace) -> dict[str, Any]:
        """The task, multi-step: construct the plan, choose tools, execute, repair.

        ``replans`` is 0 **always**. Recovery is repair within the plan; forming
        a new plan is the DL3 discriminator, and a DL2 that replanned would be a
        DL3 with a cheaper label.
        """
        task = contract.get("task", "")
        inputs = dict(contract.get("inputs") or {})
        steps, approach = self._plan(
            out, trace, purpose="construct_plan", brief=f"task: {task}",
            inputs=inputs, strategy=None,
        )
        artifacts = {"plan": _write_json(out / "plan.json", {
            "task": task,
            "approach": approach,
            "steps": steps,
            "constructed_decomposition": True,
            "recovery_budget": self.MAX_RECOVERIES,
            "replans": 0,
            "note": (
                "The contract supplied no procedure; DL2 constructed this "
                "decomposition, so `plans` is true. Recovery repairs within this "
                "plan — replanning is DL3's discriminator and DL2 never does it."
            ),
        })}
        if not steps:
            return {
                "argv": [f"{self.executor_id}:empty-plan"],
                "exit_code": EXIT_PLANNING,
                "artifacts": artifacts,
                # PLANNING, not SPECIFICATION: DL2 was asked to construct a
                # decomposition and could not. Calling that a specification
                # failure would blur the one signal T2's refusal depends on.
                "failure_class": FailureClass.PLANNING,
                "replans": 0,
            }
        ok, argv, arts, failure = self._execute_steps(
            steps, out, trace, tag="s", recoveries=self.MAX_RECOVERIES, constructed=True,
        )
        artifacts.update(arts)
        return {
            "argv": argv or [f"{self.executor_id}:no-steps"],
            "exit_code": EXIT_OK if ok else _EXIT_FOR_FAILURE[failure],
            "artifacts": artifacts,
            "failure_class": None if ok else failure,
            "replans": 0,
        }

    def _run_dl3(self, contract, out, trace) -> dict[str, Any]:
        """Outcome + constraints only: construct the strategy, and replace it when it fails.

        DL3 does not repair in place. When the plan fails it **discards the
        strategy and forms a new one** — one ``replan`` call per replan, up to
        the declared :data:`MAX_REPLANS`, each increment visible in
        ``ExecutionResult.replans``. A DL3 without replans is a DL2 with a
        different label.
        """
        outcome_text = contract.get("outcome", "")
        constraints = dict(contract.get("constraints") or {})
        inputs = dict(constraints.get("inputs") or {})
        max_operations = constraints.get("max_operations")

        strategy = self._call(
            "construct_strategy",
            f"outcome: {outcome_text}\nconstraints: {sorted(constraints)}\n"
            "no procedure and no task were supplied; name a strategy.",
            trace,
        ).strip()

        replans = 0
        attempts: list[dict[str, Any]] = []
        strategies = [strategy]
        argv: list[str] = []
        artifacts: dict[str, str] = {}
        ok = False
        failure: FailureClass | None = None

        while True:
            steps, approach = self._plan(
                out, trace, purpose="construct_plan",
                brief=f"outcome: {outcome_text}", inputs=inputs, strategy=strategy,
            )
            attempt_no = len(attempts)
            record: dict[str, Any] = {
                "attempt": attempt_no, "strategy": strategy,
                "approach": approach, "steps": steps,
            }
            if not steps:
                ok, failure = False, FailureClass.PLANNING
                record["outcome"] = "no decomposition could be constructed"
            elif isinstance(max_operations, int) and len(steps) > max_operations:
                # A declared constraint is a limit only if exceeding it stops the run.
                ok, failure = False, FailureClass.PLANNING
                record["outcome"] = (
                    f"plan of {len(steps)} operations exceeds the contract's "
                    f"max_operations={max_operations}"
                )
            else:
                ok, a, arts, failure = self._execute_steps(
                    steps, out, trace, tag=f"a{attempt_no}s", recoveries=0, constructed=True,
                )
                argv.extend(a)
                artifacts.update(arts)
                record["outcome"] = "ok" if ok else f"failed: {failure.value}"
            attempts.append(record)

            if ok or replans >= self.MAX_REPLANS:
                break
            replans += 1
            strategy = self._call(
                "replan",
                f"outcome: {outcome_text}\nstrategy {strategy!r} failed "
                f"({record['outcome']}). Discard it and name a new one "
                f"(replan {replans} of {self.MAX_REPLANS}).",
                trace,
            ).strip()
            strategies.append(strategy)

        artifacts["strategy"] = _write_json(out / "strategy.json", {
            "outcome": outcome_text,
            "constraints": constraints,
            "strategies_in_order": strategies,
            "replans": replans,
            "max_replans": self.MAX_REPLANS,
            "note": (
                "Each replan DISCARDED the strategy above it and formed a new "
                "one. Repair within a plan is DL2's move; replacing the plan is "
                "what makes this level DL3."
            ),
        })
        artifacts["plan"] = _write_json(out / "plan.json", {
            "outcome": outcome_text,
            "attempts": attempts,
            "constructed_decomposition": True,
            "replans": replans,
            "note": (
                "The contract supplied neither a procedure nor a task. DL3 "
                "constructed the strategy and every plan below it, so `plans` is true."
            ),
        })
        return {
            "argv": argv or [f"{self.executor_id}:no-steps"],
            "exit_code": EXIT_OK if ok else _EXIT_FOR_FAILURE[failure],
            "artifacts": artifacts,
            "failure_class": None if ok else failure,
            "replans": replans,
        }


def _decompose(inputs: Mapping[str, Any]) -> list[dict[str, Any]]:
    """The decomposition DL2 and DL3 construct, from the inputs alone.

    Deterministic, and deliberately not the client's to choose: the client picks
    the *tool* for a step, and the executor is answerable for the steps. Two
    files means digest each and compare the bytes.
    """
    a, b = inputs.get("path_a"), inputs.get("path_b")
    steps: list[dict[str, Any]] = []
    if isinstance(a, str):
        steps.append({"operation": "hash_file", "args": {"path": a, "algo": "sha256"},
                      "why": "digest the first input"})
    if isinstance(b, str):
        steps.append({"operation": "hash_file", "args": {"path": b, "algo": "sha256"},
                      "why": "digest the second input"})
    if isinstance(a, str) and isinstance(b, str):
        steps.append({"operation": "compare_bytes", "args": {"path_a": a, "path_b": b},
                      "why": "establish whether the two inputs are byte-identical"})
    return steps


class DL0Executor(_TierExecutor):
    """One declared operation, executed deterministically.

    Holds **no reference to a model client at all** — :func:`executor_for` drops
    one if it is offered. RULING 2 requirement 1 is not a boolean here; there is
    no attribute to call. A DL0 whose cost is indistinguishable from DL3's has
    been named, not built.

    This is the in-process primitive the tier's higher levels run their steps
    through; the shipped ``dli-dl0`` binary is unchanged and is not rebuilt here.
    """

    LEVEL = "DL0"
    PLANS = False
    NEEDS_CLIENT = False
    _DEFAULT_ID = "dl-brain:dl0"

    def _compute_cost(self, trace) -> float | None:
        return 0.0  # Measured, not declared: there is no client to bill.

    def _run_dl1(self, contract, out, trace):  # pragma: no cover - refused earlier
        self._above_my_level("DL1")

    def _run_dl2(self, contract, out, trace):  # pragma: no cover - refused earlier
        self._above_my_level("DL2")

    def _run_dl3(self, contract, out, trace):  # pragma: no cover - refused earlier
        self._above_my_level("DL3")


class DL1Executor(_TierExecutor):
    """Goal + the known procedure, bound into a concrete call sequence.

    No plan artifact, no recovery, no replans. Its decomposition was supplied.
    """

    LEVEL = "DL1"
    PLANS = False
    NEEDS_CLIENT = True
    MAX_REPLANS = 0
    MAX_RECOVERIES = 0
    _DEFAULT_ID = "dl-brain:dl1"

    def _run_dl2(self, contract, out, trace):  # pragma: no cover - refused earlier
        self._above_my_level("DL2")

    def _run_dl3(self, contract, out, trace):  # pragma: no cover - refused earlier
        self._above_my_level("DL3")


class DL2Executor(_TierExecutor):
    """The task: plan, tool choice, state, recovery. Never a replan."""

    LEVEL = "DL2"
    PLANS = True
    NEEDS_CLIENT = True
    MAX_REPLANS = 0
    MAX_RECOVERIES = MAX_RECOVERIES
    _DEFAULT_ID = "dl-brain:dl2"

    def _run_dl3(self, contract, out, trace):  # pragma: no cover - refused earlier
        self._above_my_level("DL3")


class DL3Executor(_TierExecutor):
    """Outcome + constraints: the strategy itself, replaced when it fails."""

    LEVEL = "DL3"
    PLANS = True
    NEEDS_CLIENT = True
    MAX_REPLANS = MAX_REPLANS
    MAX_RECOVERIES = 0  # DL3 replaces the plan; it does not repair inside it.
    _DEFAULT_ID = "dl-brain:dl3"


_EXECUTORS: dict[str, type[_TierExecutor]] = {
    "DL0": DL0Executor,
    "DL1": DL1Executor,
    "DL2": DL2Executor,
    "DL3": DL3Executor,
}


def executor_for(level: str, *, model_client: ModelClient | None = None, **kwargs) -> Executor:
    """The executor holding ``level``, with its model client injected.

    ``DL0`` is constructed **without** the client, even when one is passed: the
    zero in ``DL0 = 0 < DL1`` is then structural rather than declared, because
    the object has nothing to call.
    """
    if level not in DL_TIER_LEVELS:
        raise ValueError(
            f"unknown DL level {level!r}; known levels are {list(DL_TIER_LEVELS)}"
        )
    cls = _EXECUTORS[level]
    if level == "DL0":
        return cls(**kwargs)
    return cls(model_client=model_client, **kwargs)
