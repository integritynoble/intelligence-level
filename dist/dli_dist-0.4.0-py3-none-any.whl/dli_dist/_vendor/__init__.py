"""Generated at build time by tools/build_dist.py — do not edit, do not commit.

The vendored dl-brain tier, copied into the package so it ships inside the
wheel and the zipapp and resolves by import machinery inside a zip.
"""
