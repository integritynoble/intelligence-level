"""A JSON Schema validator over the stdlib only.

`jsonschema` is not installed on this account (BASELINE.md) and adding a
dependency would push a hidden precondition onto everyone who downloads a binary
from this lane. So this module implements the subset of JSON Schema draft 2020-12
that this lane's two schemas actually use — and it **fails loudly on any keyword
it does not implement** rather than ignoring it. A validator that silently skips
an unknown keyword is worse than none: the schema author believes a constraint is
enforced when nothing enforces it.

This is structural validation only. Cross-field rules that JSON Schema cannot
express (the DL0 cost rule; the episode record's sigma/p_star/risk_provenance
recomputations) live beside the schema they belong to — `dli_dist.capabilities`
and `dli_dist.episode` — because a derived check that travels away from its schema
is a check that gets forgotten.

The structural subset here is an independent re-implementation of the contract in
`vendor/dl-brain-<tier-sha8>/*.schema.json`; it is deliberately NOT an import of
`dl-brain`'s own validator, so that `dli-dl0` runs on a bare Python.
"""

from __future__ import annotations

import datetime as _dt
import json
import re
from pathlib import Path
from typing import Any

__all__ = [
    "SchemaError",
    "ValidationError",
    "load_schema",
    "load_schema_text",
    "validate",
    "parse_instant",
]

#: Every keyword this validator understands. A schema using anything else is
#: refused at load time.
_SUPPORTED = {
    "$schema", "$id", "title", "description", "type", "required", "properties",
    "additionalProperties", "enum", "const", "minimum", "maximum",
    "exclusiveMinimum", "exclusiveMaximum", "minLength", "maxLength",
    "minItems", "maxItems", "minProperties", "items", "format", "pattern",
}

_TYPES: dict[str, Any] = {
    "object": dict, "array": list, "string": str, "boolean": bool,
    "number": (int, float), "integer": int, "null": type(None),
}

_INSTANT = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$")


class SchemaError(Exception):
    """The schema itself is malformed or uses an unimplemented keyword."""


class ValidationError(Exception):
    """The instance does not satisfy the schema. Carries a JSON path."""

    def __init__(self, path: str, message: str) -> None:
        self.path = path or "$"
        self.message = message
        super().__init__(f"{self.path}: {message}")


def parse_instant(text: str, path: str = "$") -> _dt.datetime:
    """Parse a UTC instant. Reject anything without an explicit trailing ``Z``.

    A naive timestamp is refused rather than assumed-UTC: a duration computed
    across an assumed timezone is a silently wrong number.
    """
    if not isinstance(text, str) or not _INSTANT.match(text):
        raise ValidationError(
            path, f"not a UTC instant (need YYYY-MM-DDTHH:MM:SS[.fff]Z): {text!r}"
        )
    return _dt.datetime.fromisoformat(text.replace("Z", "+00:00"))


def load_schema_text(text: str) -> dict:
    """Parse a schema from its JSON text, refusing any unimplemented keyword.

    The load path that works inside a wheel or a zipapp, where the schema arrives
    as bytes from ``importlib.resources`` rather than a filesystem path.
    """
    schema = json.loads(text)
    _audit(schema, "$")
    return schema


def load_schema(path: str | Path) -> dict:
    """Load a schema from a filesystem path, refusing unimplemented keywords."""
    return load_schema_text(Path(path).read_text(encoding="utf-8"))


def _audit(node: Any, path: str) -> None:
    if not isinstance(node, dict):
        return
    unknown = set(node) - _SUPPORTED
    if unknown:
        raise SchemaError(
            f"{path}: unimplemented keyword(s) {sorted(unknown)} — this validator "
            "refuses rather than silently ignoring them"
        )
    for name, sub in (node.get("properties") or {}).items():
        _audit(sub, f"{path}.properties.{name}")
    if isinstance(node.get("additionalProperties"), dict):
        _audit(node["additionalProperties"], f"{path}.additionalProperties")
    if isinstance(node.get("items"), dict):
        _audit(node["items"], f"{path}.items")


def validate(instance: Any, schema: dict) -> None:
    """Raise ``ValidationError`` on the first structural violation, else return None."""
    _validate(instance, schema, "$")


def _validate(inst: Any, sch: dict, path: str) -> None:
    if "type" in sch:
        types = sch["type"]
        types = [types] if isinstance(types, str) else types
        for name in types:
            if name not in _TYPES:
                raise SchemaError(f"{path}: unknown type {name!r}")
        py = tuple(_TYPES[n] for n in types)
        ok = isinstance(inst, py)
        # bool is a subclass of int; a boolean is not a number here.
        if isinstance(inst, bool) and "boolean" not in types:
            ok = False
        if ok and "integer" in types and isinstance(inst, float):
            ok = inst.is_integer()
        if not ok:
            raise ValidationError(
                path, f"expected type {types}, got {type(inst).__name__}"
            )

    if "enum" in sch and inst not in sch["enum"]:
        raise ValidationError(path, f"{inst!r} not in enum {sch['enum']}")
    if "const" in sch and inst != sch["const"]:
        raise ValidationError(path, f"{inst!r} != const {sch['const']!r}")

    if isinstance(inst, str):
        if "minLength" in sch and len(inst) < sch["minLength"]:
            raise ValidationError(path, f"shorter than minLength {sch['minLength']}")
        if "maxLength" in sch and len(inst) > sch["maxLength"]:
            raise ValidationError(path, f"longer than maxLength {sch['maxLength']}")
        if "pattern" in sch and not re.search(sch["pattern"], inst):
            raise ValidationError(path, f"does not match {sch['pattern']!r}")
        if sch.get("format") == "utc-instant":
            parse_instant(inst, path)

    if isinstance(inst, (int, float)) and not isinstance(inst, bool):
        for key, op, sym in (
            ("minimum", lambda a, b: a >= b, ">="),
            ("maximum", lambda a, b: a <= b, "<="),
            ("exclusiveMinimum", lambda a, b: a > b, ">"),
            ("exclusiveMaximum", lambda a, b: a < b, "<"),
        ):
            if key in sch and not op(inst, sch[key]):
                raise ValidationError(path, f"{inst} not {sym} {sch[key]}")

    if isinstance(inst, list):
        if "minItems" in sch and len(inst) < sch["minItems"]:
            raise ValidationError(path, f"fewer than minItems {sch['minItems']}")
        if "maxItems" in sch and len(inst) > sch["maxItems"]:
            raise ValidationError(path, f"more than maxItems {sch['maxItems']}")
        if isinstance(sch.get("items"), dict):
            for i, item in enumerate(inst):
                _validate(item, sch["items"], f"{path}[{i}]")

    if isinstance(inst, dict):
        if "minProperties" in sch and len(inst) < sch["minProperties"]:
            raise ValidationError(
                path, f"fewer than minProperties {sch['minProperties']}"
            )
        for name in sch.get("required", []):
            if name not in inst:
                raise ValidationError(path, f"missing required property {name!r}")
        props = sch.get("properties", {})
        for name, value in inst.items():
            if name in props:
                _validate(value, props[name], f"{path}.{name}")
            else:
                extra = sch.get("additionalProperties", True)
                if extra is False:
                    raise ValidationError(path, f"unexpected property {name!r}")
                if isinstance(extra, dict):
                    _validate(value, extra, f"{path}.{name}")
