"""Resolve the two JSON Schemas this lane validates against — from a source
checkout, an installed wheel, or a zipapp alike.

In a checkout the schemas sit at the repo root (``schemas/`` and
``vendor/dl-brain-<tier-sha8>/``), reachable with ``pathlib``. A wheel drops
``dli_dist`` into ``site-packages`` with no repo root above it, and a zipapp keeps
the package inside a zip where ``pathlib`` cannot read a member at all — so a
``Path(__file__).parent.parent / "schemas"`` read that works in a checkout raises
in both packaged forms, and ``dli-dl0 --capabilities`` (which validates its own
output before printing) would fail on precisely the artifact the acceptance test
is about.

So the build copies the two schema files verbatim into ``dli_dist/_data/`` as
package data, and this module reads them with ``importlib.resources`` — which
reads a real directory, a zip member, and an installed package uniformly. A
source checkout carries no ``_data/`` (it is generated at build), so it falls back
to the canonical repo-root files. The bytes are identical either way, so a record
this lane accepts in a checkout is one it accepts when packaged. Stdlib only.
"""

from __future__ import annotations

import importlib.resources as _res
from pathlib import Path

from dli_dist import _build

__all__ = ["schema_text", "CAPABILITIES_SCHEMA", "EPISODE_SCHEMA"]

CAPABILITIES_SCHEMA = "capabilities.schema.json"
EPISODE_SCHEMA = "episode_record.schema.json"

#: Repo-root fallbacks, used only in a source checkout that has no baked _data/.
#: The vendor directory is derived from ``_build.TIER_SHA[:8]`` rather than typed,
#: so the re-pinned tier SHA and this path cannot drift apart.
_ROOT = Path(__file__).resolve().parent.parent
_FS_FALLBACK = {
    CAPABILITIES_SCHEMA: _ROOT / "schemas" / CAPABILITIES_SCHEMA,
    EPISODE_SCHEMA: _ROOT / "vendor" / f"dl-brain-{_build.TIER_SHA[:8]}" / EPISODE_SCHEMA,
}


def schema_text(name: str) -> str:
    """Return the JSON text of one schema by filename, wherever the code runs."""
    # Packaged: the baked copy under dli_dist/_data, read as a resource so a zip
    # member or an installed file resolves without a real filesystem path.
    try:
        data = _res.files("dli_dist").joinpath("_data").joinpath(name)
        if data.is_file():
            return data.read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError, OSError):
        pass
    # Source checkout: the canonical repo-root file.
    return _FS_FALLBACK[name].read_text(encoding="utf-8")
