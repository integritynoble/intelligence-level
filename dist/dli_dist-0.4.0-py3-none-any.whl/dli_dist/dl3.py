"""dli-dl3 — outcome + constraints only: the strategy itself.

RULING 2's DL3: the contract names an outcome and the constraints on reaching
it, and supplies neither a task nor a procedure. This binary constructs the
strategy (one ``construct_strategy`` call), then plans and executes the way DL2
does — and when the plan fails it **discards the strategy and forms a new one**,
one ``replan`` call per replan, up to the declared ``max_replans``.

Every replan is counted into ``agent_replans`` in the emitted record. That
number is the discriminator: a DL3 that never replans is a DL2 with a different
label, and the ratchet reading the record would be learning a fiction about how
far the frontier reaches.

DL3 does not repair in place. Repair within a plan is DL2's move; DL3 replaces
the plan. When the replan budget is spent, the run stops and reports the
world's failure — a motor that retried forever would report its own patience as
the task's difficulty.

``plans`` is true, checked against the plan artifact on disk. DL3 admits every
contract shape at or below it, and its own shape is the top of this tier, so
nothing above it exists to refuse; the refusal path is exercised at DL1 and DL2.

The behaviour lives in the vendored ``dl_brain.tier``; this module is the
binding. Stdlib only, and no network client is imported here or anywhere it
reaches.
"""

from __future__ import annotations

import sys
from typing import Any

from dli_dist import _tier_exec
from dli_dist._record import ContractError

__all__ = [
    "EXECUTOR_ID",
    "ACCEPTANCE_ROLE",
    "LEVEL",
    "PLANS",
    "MAX_REPLANS",
    "OPERATIONS",
    "MAX_ARTIFACT_BYTES",
    "ContractError",
    "execute",
]

EXECUTOR_ID = "dli-dl3"

#: A performer, never an acceptor (F6). See ``dl1.ACCEPTANCE_ROLE``.
ACCEPTANCE_ROLE = False

LEVEL = "DL3"

#: True, and checkable: DL3 leaves the strategy and every plan under it on disk.
PLANS = True

#: The declared replan budget, so "up to" is a number a reader can check against
#: ``agent_replans`` rather than a promise. Kept in sync with the vendored tier
#: by a test.
MAX_REPLANS = 2

OPERATIONS = _tier_exec.OPERATIONS
MAX_ARTIFACT_BYTES = _tier_exec.MAX_ARTIFACT_BYTES


def execute(contract: dict[str, Any], *, model_client: Any = None) -> dict[str, Any]:
    """Run the contract at DL3 and return ``{"record", "exit_code"}``."""
    return _tier_exec.run_tier_contract(
        contract,
        level=LEVEL,
        executor_id=EXECUTOR_ID,
        acceptance_role=ACCEPTANCE_ROLE,
        plans=PLANS,
        model_client=model_client,
    )


def _main(argv: list[str]) -> int:
    """`exec --contract c.json` path, shared by the CLI. Returns an exit code."""
    return _tier_exec.main(argv, executor_id=EXECUTOR_ID, execute=execute)


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
