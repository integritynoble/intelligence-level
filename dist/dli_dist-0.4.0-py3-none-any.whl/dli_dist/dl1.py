"""dli-dl1 — goal + the known procedure, bound into a call sequence and run.

RULING 2's DL1: the contract supplies the decomposition; this binary binds the
parameters it left open and executes the sequence. It calls the model **once per
unbound parameter** and **not at all** when the procedure arrives fully bound.

What DL1 is not
---------------
It does not plan. Its decomposition was handed to it, so ``plans`` is false and
it leaves a ``call_sequence`` artifact rather than a plan — a distinction that is
checked against the artifact on disk, not against this sentence. It does not
recover and it does not replan: ``agent_replans`` is 0 in every record it emits.

A contract shaped for DL2 or DL3 is **refused** — non-zero exit, failure class
``specification``, zero model calls. The level is a limit, not a label.

The behaviour lives in the vendored ``dl_brain.tier``; this module is the
binding. Stdlib only, and no network client is imported here or anywhere it
reaches.
"""

from __future__ import annotations

import sys
from typing import Any

from dli_dist import _tier_exec
from dli_dist._record import ContractError

__all__ = [
    "EXECUTOR_ID",
    "ACCEPTANCE_ROLE",
    "LEVEL",
    "PLANS",
    "OPERATIONS",
    "MAX_ARTIFACT_BYTES",
    "ContractError",
    "execute",
]

EXECUTOR_ID = "dli-dl1"

#: A PERFORMER, not an acceptor: it does the work and never judges it. Single
#: source of truth for the capabilities document and for the role handed to
#: ``draft_episode``, so a downloader reading ``--capabilities`` and the guard
#: that refuses self-certification cannot disagree about what this is (F6).
ACCEPTANCE_ROLE = False

LEVEL = "DL1"

#: False, and checkable: DL1 leaves no constructed-plan artifact.
PLANS = False

OPERATIONS = _tier_exec.OPERATIONS
MAX_ARTIFACT_BYTES = _tier_exec.MAX_ARTIFACT_BYTES


def execute(contract: dict[str, Any], *, model_client: Any = None) -> dict[str, Any]:
    """Run the contract at DL1 and return ``{"record", "exit_code"}``.

    ``model_client`` is injected for tests and embedders; left ``None`` it is
    resolved from ``DLI_MODEL_CLIENT``, and an over-level contract is refused
    without resolving one at all.
    """
    return _tier_exec.run_tier_contract(
        contract,
        level=LEVEL,
        executor_id=EXECUTOR_ID,
        acceptance_role=ACCEPTANCE_ROLE,
        plans=PLANS,
        model_client=model_client,
    )


def _main(argv: list[str]) -> int:
    """`exec --contract c.json` path, shared by the CLI. Returns an exit code."""
    return _tier_exec.main(argv, executor_id=EXECUTOR_ID, execute=execute)


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
