"""Read kappa from the pinned benchmark — never invent it.

RULING 3 §2 and the executor brief: any kappa a contract carries must come from
the pinned DLI-Bench file, and a fabricated kappa must be refused loudly. This
module is the only place this lane reads that file, and it enforces two things:

1. **Metadata only.** Of every row it reads exactly these fields —
   ``task_id``, ``task_band``, ``split``, ``stratum``, ``kappa``, and the
   ``difficulty_*`` family — and it discards the rest of the parsed line
   immediately. Opening ``delegation_prompt``, ``success_criterion``,
   ``verifier`` or ``deliverables`` is verification leakage that invalidates the
   research program, so this module projects each parsed row onto the whitelist
   before returning it and never exposes the raw row. (``json.loads`` unavoidably
   parses the whole line; the discipline is that no non-whitelisted field is
   stored, returned, or acted on.) ``task_band``/``split``/``stratum`` are read
   only to *check permission* — this lane may read one row set, not to do work.

   **Permission.** This lane may read only the T1 ``dev`` ``ladder`` rows (the
   conservative reading of the charter under RULING 3 §4.4). A ``benchmark_task_id``
   naming any other real row — a T0 row, a ``validation`` row — is refused with
   ``KappaPermissionError`` naming the band found. Reading a row the charter
   excludes is leakage even when only metadata is taken.

2. **Pinned bytes.** The file's sha256 is checked against the pin before any row
   is read. A kappa read from an unknown file is a kappa about an unknown file.

The pin, from RULING3_ACK.md §1 and plan0.md:
    dli_bench_tasks_v0_2.jsonl
    270fbec33476e492f476ad496b98839e15165b145c527ce971655ebbbf89159f
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

__all__ = [
    "BENCHMARK_PATH",
    "BENCHMARK_SHA256",
    "KappaProvenanceError",
    "KappaPermissionError",
    "PERMITTED_BAND",
    "PERMITTED_SPLIT",
    "PERMITTED_STRATUM",
    "row_metadata",
    "verify_contract_kappa",
]

BENCHMARK_PATH = Path(
    os.environ.get(
        "DLI_BENCH_PATH",
        "/home/spiritai/pwm/sarsi_intelligence_level/dataset/dli_bench_tasks_v0_2.jsonl",
    )
)
BENCHMARK_SHA256 = (
    "270fbec33476e492f476ad496b98839e15165b145c527ce971655ebbbf89159f"
)

#: The only fields this lane may read from a benchmark row. Everything else is a
#: body field and opening it is verification leakage. ``task_band`` is on the
#: list because reading it is how permission is *checked* (below), not how work
#: is done — it is a label, not a body field like ``delegation_prompt``.
_ALLOWED_PREFIXES = ("difficulty_",)
_ALLOWED_EXACT = frozenset({"task_id", "task_band", "split", "stratum", "kappa"})

#: The one row set this lane is permitted to read, the conservative reading of
#: the charter under RULING 3 §4.4: the T1 `dev` `ladder` rows. The charter's
#: "you may look at the 12 T1 dev rows" is NOT a function of band (v0.2 has T1
#: rows in all three splits and dev rows in every band T0..TΩ — see
#: KNOWN_DEFECTS.md), so the permitted set is pinned by all three coordinates,
#: not inferred from the band alone.
PERMITTED_BAND = "T1"
PERMITTED_SPLIT = "dev"
PERMITTED_STRATUM = "ladder"


class KappaProvenanceError(Exception):
    """A contract's kappa cannot be traced to the pinned benchmark, or the
    pinned benchmark's bytes do not match the pin."""


class KappaPermissionError(KappaProvenanceError):
    """A benchmark row is real but outside the set this lane may read.

    A subclass of ``KappaProvenanceError`` so existing callers still refuse, but
    distinct so the CLI can give it its own exit code: reading a row the charter
    excludes is a discipline violation, not a fabricated-kappa violation."""


def _project(row: dict[str, Any]) -> dict[str, Any]:
    """Keep only whitelisted metadata; drop every body field on the spot."""
    kept: dict[str, Any] = {}
    for key, value in row.items():
        if key in _ALLOWED_EXACT or any(key.startswith(p) for p in _ALLOWED_PREFIXES):
            kept[key] = value
    return kept


def _require_permitted(meta: dict[str, Any]) -> None:
    """Refuse a row outside the T1/dev/ladder set this lane may read.

    Reads only ``task_band``/``split``/``stratum`` — all whitelisted metadata,
    and the check is precisely what permission means. The message names the band
    (and split/stratum) actually found, so a refusal says *why* it refused. No
    body field is consulted.
    """
    band = meta.get("task_band")
    split = meta.get("split")
    stratum = meta.get("stratum")
    if (band, split, stratum) != (PERMITTED_BAND, PERMITTED_SPLIT, PERMITTED_STRATUM):
        raise KappaPermissionError(
            f"benchmark row {meta.get('task_id')!r} is task_band={band!r} "
            f"split={split!r} stratum={stratum!r}; this lane may read only "
            f"task_band={PERMITTED_BAND!r} split={PERMITTED_SPLIT!r} "
            f"stratum={PERMITTED_STRATUM!r} rows (the charter's T1 dev rows, "
            "conservative ladder-only reading under RULING 3 §4.4) — reading a "
            "row outside that set is verification leakage, refused"
        )


def _verify_bytes(path: Path) -> None:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != BENCHMARK_SHA256:
        raise KappaProvenanceError(
            f"benchmark at {path} has sha256 {digest}, not the pinned "
            f"{BENCHMARK_SHA256} — a kappa read from it would be about an "
            "unknown file"
        )


def row_metadata(
    task_id: str,
    path: Path | None = None,
    *,
    verify_sha: bool = True,
    enforce_charter: bool = True,
) -> dict[str, Any]:
    """Return the whitelisted metadata for one benchmark row, or raise.

    Only ``task_id``, ``task_band``, ``split``, ``stratum``, ``kappa`` and
    ``difficulty_*`` are ever returned. No body field is opened.

    When ``enforce_charter`` is true (the default), a row outside the permitted
    T1/dev/ladder set raises ``KappaPermissionError`` — this lane may not read
    any other row of the pinned benchmark. Synthetic, non-benchmark files read
    with ``verify_sha=False`` may pass ``enforce_charter=False``.
    """
    path = path or BENCHMARK_PATH
    if not path.exists():
        raise KappaProvenanceError(f"pinned benchmark not found at {path}")
    if verify_sha:
        _verify_bytes(path)
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            if row.get("task_id") == task_id:
                meta = _project(row)
                if enforce_charter:
                    _require_permitted(meta)
                return meta
    raise KappaProvenanceError(
        f"task_id {task_id!r} is not a row in the pinned benchmark — an invented "
        "kappa has no provenance and is refused (RULING 3 §2)"
    )


def verify_contract_kappa(
    contract: dict[str, Any], path: Path | None = None, *, verify_sha: bool = True
) -> dict[str, Any]:
    """Verify the kappa a contract carries against the pinned benchmark.

    A contract that carries kappa must declare which benchmark ``task_id`` it was
    read from, in ``kappa_provenance.benchmark_task_id``. This function:

    * refuses a kappa with no ``kappa_provenance`` block (an invented kappa),
    * refuses a ``task_id`` absent from the pinned file,
    * refuses a ``verifiability`` or ``risk`` that disagrees with the row,
    * pins ``risk`` to the row's ``difficulty_risk`` — the source field — so a
      future divergence between the benchmark's two names for that coordinate is
      loud rather than silent (RULING 3 §2). The value is risk on the increasing
      scale 0 = trivially undoable, 5 = irreversible; read the value, never the
      key name.

    Returns the whitelisted row metadata it validated against.
    """
    kappa = contract.get("kappa")
    if not isinstance(kappa, dict):
        raise KappaProvenanceError(
            "contract carries no kappa object; nothing to verify"
        )
    prov = contract.get("kappa_provenance")
    if not isinstance(prov, dict) or not prov.get("benchmark_task_id"):
        raise KappaProvenanceError(
            "contract kappa has no kappa_provenance.benchmark_task_id — an "
            "invented kappa is refused (RULING 3 §2). Every kappa this lane "
            "ships is read from the pinned benchmark, never chosen."
        )

    row = row_metadata(prov["benchmark_task_id"], path, verify_sha=verify_sha)

    row_kappa = row.get("kappa") or {}
    # The benchmark row's kappa dict uses the key 'reversibility' for the risk
    # coordinate; difficulty_risk is the source field. Pin them equal so a
    # divergence surfaces here instead of silently shipping a wrong risk.
    row_reversibility = row_kappa.get("reversibility")
    difficulty_risk = row.get("difficulty_risk")
    if row_reversibility != difficulty_risk:
        raise KappaProvenanceError(
            f"benchmark row {prov['benchmark_task_id']!r}: kappa.reversibility "
            f"({row_reversibility}) != difficulty_risk ({difficulty_risk}) — the "
            "benchmark's two names for the risk coordinate have diverged"
        )

    claimed_verifiability = kappa.get("verifiability")
    if claimed_verifiability != row_kappa.get("verifiability"):
        raise KappaProvenanceError(
            f"contract kappa.verifiability ({claimed_verifiability}) disagrees "
            f"with benchmark row ({row_kappa.get('verifiability')}) — kappa is "
            "read, not chosen"
        )
    claimed_risk = kappa.get("risk")
    if claimed_risk != difficulty_risk:
        raise KappaProvenanceError(
            f"contract kappa.risk ({claimed_risk}) disagrees with benchmark "
            f"difficulty_risk ({difficulty_risk}) — kappa is read, not chosen"
        )
    return row
