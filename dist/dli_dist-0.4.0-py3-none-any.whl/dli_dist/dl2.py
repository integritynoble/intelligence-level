"""dli-dl2 — the task, multi-step: plan, tool choice, state, recovery.

RULING 2's DL2: the contract supplies a task and no procedure, so this binary
**constructs the decomposition** — one ``construct_plan`` call, one
``choose_tool`` call per planned step — executes it, and on a step that fails
spends one ``recover`` call and one retry.

The line that makes DL2 a level rather than a label
---------------------------------------------------
``agent_replans`` is **0 in every record it emits.** Recovery repairs a step
*within* the plan it already has; forming a new plan is DL3's discriminator. A
DL2 that replanned would be a DL3 wearing a cheaper cost model, and the router
that believed the cost model would be routing on a fiction.

``plans`` is true, and it is checked against the plan artifact on disk. A
contract shaped for DL3 (outcome + constraints, no task) is refused — non-zero
exit, failure class ``specification``, zero model calls.

The behaviour lives in the vendored ``dl_brain.tier``; this module is the
binding. Stdlib only, and no network client is imported here or anywhere it
reaches.
"""

from __future__ import annotations

import sys
from typing import Any

from dli_dist import _tier_exec
from dli_dist._record import ContractError

__all__ = [
    "EXECUTOR_ID",
    "ACCEPTANCE_ROLE",
    "LEVEL",
    "PLANS",
    "OPERATIONS",
    "MAX_ARTIFACT_BYTES",
    "ContractError",
    "execute",
]

EXECUTOR_ID = "dli-dl2"

#: A performer, never an acceptor (F6). See ``dl1.ACCEPTANCE_ROLE``.
ACCEPTANCE_ROLE = False

LEVEL = "DL2"

#: True, and checkable: DL2 leaves the plan it constructed on disk.
PLANS = True

OPERATIONS = _tier_exec.OPERATIONS
MAX_ARTIFACT_BYTES = _tier_exec.MAX_ARTIFACT_BYTES


def execute(contract: dict[str, Any], *, model_client: Any = None) -> dict[str, Any]:
    """Run the contract at DL2 and return ``{"record", "exit_code"}``."""
    return _tier_exec.run_tier_contract(
        contract,
        level=LEVEL,
        executor_id=EXECUTOR_ID,
        acceptance_role=ACCEPTANCE_ROLE,
        plans=PLANS,
        model_client=model_client,
    )


def _main(argv: list[str]) -> int:
    """`exec --contract c.json` path, shared by the CLI. Returns an exit code."""
    return _tier_exec.main(argv, executor_id=EXECUTOR_ID, execute=execute)


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
