"""Capabilities documents for ``dli-dl1``, ``dli-dl2`` and ``dli-dl3``.

The schema (``schemas/capabilities.schema.json``) is fixed, public, and
``additionalProperties: false``. The tier therefore declares itself **within**
it and invents no new top-level key: a level that needed a new field to describe
itself would be telling downloaders something their validator throws away.

The two declarations that are load-bearing
------------------------------------------
**``usd_per_invocation`` is ``null`` for all three, and that is not a shortcut.**
There is no model credential on this account; no invocation of these binaries has
ever been billed. ``null`` is the idiom this lane already uses for unmeasured
(``stub_capabilities``) and the schema permits it (``["number","null"]``). A
plausible dollar figure here would be arithmetic on an invented price — a
fabrication dressed as a measurement, and the one kind of dishonesty a
capabilities document exists to prevent.

**``llm_calls_per_invocation`` is compared against measurement, not trusted.**
The numbers below are the control-flow cost of each level over the task family in
``tools/tier_family.py``, whose measured totals are recorded in
``artifacts/t1_cost.json`` (DL0=0, DL1=3, DL2=13, DL3=25 over that family, under
a deterministic scripted client — bounding the machinery, not real-model
behaviour). ``tools/gate_t3_honest.py`` checks the declared ordering against
those measured totals and fails a level that declares 0 while being measured
making calls. A binary that understates its cost overstates its level.

``network_required`` and ``credentials_required`` are **true** for all three, and
these modules still import no network client. The requirement is real — a model
call reaches a network and needs a secret — and the code that opens the socket
is the embedder's factory behind ``DLI_MODEL_CLIENT``, outside this package.
Declaring false because the socket is opened one import away would be exactly the
well-worded string the schema's own description warns about.

Stdlib only.
"""

from __future__ import annotations

import json
import sys
from typing import Any

from dli_dist import _build

__all__ = [
    "dl1_capabilities",
    "dl2_capabilities",
    "dl3_capabilities",
    "TIER_CAPABILITIES",
]

#: The per-invocation model-call cost of each level's control flow, over the
#: 3-step decomposition the task family exercises (digest a, digest b, compare).
#: The formula is spelled out in each document's notes so a reader can re-derive
#: the cost of a different task rather than assume this one generalises.
_CALLS = {
    "DL1": 1,   # one bind_parameter per unbound "?" parameter; 0 if fully bound
    "DL2": 4,   # 1 construct_plan + 1 choose_tool per step (3); +1 recover on a failed step
    "DL3": 5,   # 1 construct_strategy + (1 construct_plan + 3 choose_tool); +1+1+3 per replan
}

_NOTES = {
    "DL1": (
        "Goal + the known procedure. Binds each unbound '?' parameter with one "
        "bind_parameter call and runs the sequence; a fully bound procedure costs "
        "zero calls. Constructs no plan (plans=false, and it leaves a "
        "call_sequence artifact, never a plan one), never recovers, never "
        "replans: agent_replans is 0 in every record. A DL2- or DL3-shaped "
        "contract is refused with failure_class=specification at zero model "
        "calls. Cost formula: one call per unbound parameter."
    ),
    "DL2": (
        "The task, multi-step, no procedure supplied. Constructs the "
        "decomposition (plans=true, and leaves the plan on disk): 1 "
        "construct_plan call, then 1 choose_tool call per planned step, then "
        "executes; a failing step costs 1 recover call and 1 retry, and the "
        "repair budget is 1 per run. agent_replans is 0 ALWAYS — recovery repairs "
        "within the plan, and replanning is DL3's discriminator. A DL3-shaped "
        "contract is refused at zero model calls. Cost formula: 1 + steps "
        "(+1 if a step fails); 4 over this lane's 3-step family."
    ),
    "DL3": (
        "Outcome + constraints only. Constructs the strategy (1 "
        "construct_strategy call) and then plans and executes as DL2 does; when "
        "the plan fails it DISCARDS the strategy and forms a new one — 1 replan "
        "call per replan, max_replans=2, each counted into agent_replans. It does "
        "not repair in place. plans=true and the strategy and every plan under it "
        "are left on disk. Cost formula: 1 + (1 + steps) per attempt, up to 3 "
        "attempts; 5 for a clean run over this lane's 3-step family, 15 when both "
        "replans are spent."
    ),
}


def _tier_capabilities(level: str, executor_id: str, plans: bool, operations, max_bytes) -> dict[str, Any]:
    return {
        "level": level,
        "plans": plans,
        # True, and it is the honest answer: this level cannot do its work
        # without a model call. The transport is the embedder's; the requirement
        # is this binary's, so this binary declares it.
        "llm_required": True,
        "network_required": True,
        "credentials_required": True,
        # A performer, never an acceptor — sourced from the module itself so this
        # document and the self-certification guard cannot disagree (F6).
        "acceptance_role": False,
        "cost_model": {
            "llm_calls_per_invocation": _CALLS[level],
            "unit": "usd",
            # NOT MEASURED. No model credential exists on this account, so no
            # invocation was billed. null, never a plausible-looking number.
            "usd_per_invocation": None,
        },
        "declared_limits": {
            "operations": sorted(operations),
            "max_artifact_bytes": max_bytes,
            "notes": _NOTES[level],
        },
        "version": _build.VERSION,
        "build_sha": _build.BUILD_SHA,
        "tier_sha": _build.TIER_SHA,
        "executor_id": executor_id,
    }


def dl1_capabilities() -> dict[str, Any]:
    """The real DL1 capabilities document for ``dli-dl1``.

    Sourced from ``dli_dist.dl1`` — imported inside the function so a broken
    sibling cannot stop an unrelated binary from starting, the same way
    ``dl0_capabilities`` does it.
    """
    from dli_dist import dl1

    return _tier_capabilities(
        dl1.LEVEL, dl1.EXECUTOR_ID, dl1.PLANS, dl1.OPERATIONS, dl1.MAX_ARTIFACT_BYTES
    )


def dl2_capabilities() -> dict[str, Any]:
    """The real DL2 capabilities document for ``dli-dl2``."""
    from dli_dist import dl2

    return _tier_capabilities(
        dl2.LEVEL, dl2.EXECUTOR_ID, dl2.PLANS, dl2.OPERATIONS, dl2.MAX_ARTIFACT_BYTES
    )


def dl3_capabilities() -> dict[str, Any]:
    """The real DL3 capabilities document for ``dli-dl3``."""
    from dli_dist import dl3

    return _tier_capabilities(
        dl3.LEVEL, dl3.EXECUTOR_ID, dl3.PLANS, dl3.OPERATIONS, dl3.MAX_ARTIFACT_BYTES
    )


#: binary name -> its capabilities builder, for ``cli._register_real``.
TIER_CAPABILITIES = {
    "dli-dl1": dl1_capabilities,
    "dli-dl2": dl2_capabilities,
    "dli-dl3": dl3_capabilities,
}


def _main(argv: list[str]) -> int:
    if not argv or argv[0] not in TIER_CAPABILITIES:
        sys.stderr.write(
            "usage: python3 -m dli_dist.tier_capabilities <dli-dl1|dli-dl2|dli-dl3>\n"
        )
        return 2
    json.dump(TIER_CAPABILITIES[argv[0]](), sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
