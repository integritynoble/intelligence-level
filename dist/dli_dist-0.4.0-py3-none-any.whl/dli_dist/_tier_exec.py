"""Shared machinery for the ``dli-dl1`` / ``dli-dl2`` / ``dli-dl3`` bindings.

The three tier binaries differ in exactly one string — their level — and share
everything else: how they find the vendored tier, how they refuse, how they turn
an ``ExecutionResult`` into an episode record. Keeping that in one place is the
same move ``_record.py`` already makes for ``dl0`` and ``accept``: three copies
of a record builder is three chances to drift on the one field that matters.

Three properties this module exists to preserve
-----------------------------------------------
**It imports no network client, and neither do dl1/dl2/dl3.**
``tools/check_no_network_imports.py`` scans the whole ``dli_dist`` package, not
just ``dl0.py`` — a forbidden import here would take the DL0 criterion down with
it. So the tier binaries ship *no transport*. The model client is resolved
through ``DLI_MODEL_CLIENT``, a ``module:factory`` pointer the embedder sets; the
factory lives outside this package and is where a socket may legitimately be
opened. That is why these binaries declare ``network_required: true`` and
``credentials_required: true`` and still contain no networking: the requirement
is real and is declared, and the code that satisfies it is someone else's.

**A refusal costs nothing and requires nothing.** An over-level contract is
refused before a model client is even *looked for* — see
``RefusalOnlyClient``. A binary that demanded a credential in order to decline a
contract would have made its declared limit conditional on a credential.

**No verdict is authored here.** ``verification`` and ``result`` stay null;
``draft_episode`` has no argument that could fill them, and ``alpha`` is copied
from the brain-declared acceptance block, never chosen.

Stdlib only.
"""

from __future__ import annotations

import importlib
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable

from dli_dist import _build, episode, kappa
from dli_dist._record import ContractError, resolve_blocks

__all__ = [
    "OPERATIONS",
    "MAX_ARTIFACT_BYTES",
    "MODEL_CLIENT_ENV",
    "ModelClientAbsent",
    "TierAbsent",
    "RefusalOnlyClient",
    "vendored_tier",
    "resolve_model_client",
    "run_tier_contract",
    "main",
]

#: The closed set the tier will attempt, and the read cap on one artifact. Both
#: are literals rather than imports from the vendored tier so that
#: ``import dli_dist.dl1`` stays cheap and stdlib-bare even where the vendor
#: directory is absent; a test asserts they equal ``dl_brain.tier``'s, the same
#: way ``dl0_capabilities`` is kept in sync with ``dl0.OPERATIONS`` by a test.
OPERATIONS = frozenset({"hash_file", "compare_bytes"})
MAX_ARTIFACT_BYTES = 10 * 1024 * 1024

#: ``module:factory`` — the embedder's zero-argument factory returning an object
#: with ``complete(prompt, *, purpose) -> str``. Unset on this account: there is
#: no model credential here, so ``exec`` exits 6 and says so rather than
#: pretending a run happened.
MODEL_CLIENT_ENV = "DLI_MODEL_CLIENT"

# Exit codes, continuing dl0's: 2 usage, 3 refused, 4 invalid record, 5 charter.
EXIT_USAGE = 2
EXIT_REFUSED = 3
EXIT_RECORD_INVALID = 4
EXIT_CHARTER = 5
EXIT_NO_MODEL_CLIENT = 6   # precondition absent — NOT the stub's 70
EXIT_TIER_ABSENT = 7       # the vendored tier is missing from this build


class ModelClientAbsent(RuntimeError):
    """No model client is configured, so a level above DL0 cannot run.

    Deliberately distinct from the stub exit (70) and from a contract refusal
    (3). *Absent* and *present-but-failing* are different states, and a caller
    that collapses them will read a missing credential as a broken executor.
    """


class TierAbsent(RuntimeError):
    """The vendored ``dl-brain`` tier is not in this build."""


class RefusalOnlyClient:
    """A client handed only to an executor that is already proven to refuse.

    ``admits()`` has said no before this object is constructed, so the executor
    it is injected into will refuse on the contract's shape alone and never
    reach for a model. If it ever did, this raises and the binary crashes —
    which is the point. T2's property is asserted at runtime *inside the shipped
    binary*, not only in a gate that runs in the lane that wrote it.
    """

    model = None

    def complete(self, prompt: str, *, purpose: str) -> str:
        raise AssertionError(
            f"a refusal path called a model (purpose={purpose!r}). An executor "
            "that calls a model in order to decide to refuse has attempted the "
            "contract; the refusal must be structural and free."
        )


def _vendor_root() -> Path:
    """``vendor/dl-brain-<tier-sha-prefix>/`` — the pinned upstream tier.

    Derived from ``_build.TIER_SHA`` rather than globbed, so a build carrying two
    vendored copies cannot silently package the wrong one.
    """
    return (
        Path(__file__).resolve().parent.parent / "vendor" / f"dl-brain-{_build.TIER_SHA[:8]}"
    )


_TIER = None


def vendored_tier():
    """Import ``dl_brain.tier`` from the vendored copy. Cached.

    Imported lazily: ``import dli_dist.dl1`` must stay cheap, and a build missing
    the vendored tier must fail at ``exec`` with a clear message rather than at
    import time, where it would take ``dli-dl0`` down with it.

    Two locations, in order (see KNOWN_DEFECTS.md — this function is edited from
    dl-brain's upstream form to close the F8-class packaging gap):

    * **Packaged build** — the tier rides *inside* the artifact as the subpackage
      ``dli_dist._vendor.dl_brain`` (generated at build time by
      ``tools/build_dist.py``). It is reached by **normal import machinery**, not
      a filesystem probe, so it resolves inside a zipapp where a zip member is not
      a file and ``Path.is_file()`` is ``False``. ``tier.py`` does
      ``from dl_brain.executor import …``, so the packaged package is aliased under
      the bare ``dl_brain`` name (and ``dl_brain.executor`` beneath it) before
      ``dl_brain.tier`` is imported. Upstream's ``vendor/…`` filesystem path is in
      neither the zipapp nor the wheel, so a build relying on it exited 7 at
      ``exec`` while working from the source tree.
    * **Source checkout** — no generated ``_vendor/`` (it is git-ignored), so the
      repo-root ``vendor/dl-brain-<sha8>/`` tree is used, derived from
      ``_build.TIER_SHA`` so a tree carrying two copies cannot package the wrong
      one.

    ``TierAbsent`` (exit 7) is still the failure when neither is present.
    """
    global _TIER
    if _TIER is not None:
        return _TIER

    # Packaged: the tier is a subpackage of dli_dist, importable inside a zip.
    try:
        import dli_dist._vendor.dl_brain as _pkg
    except ImportError:
        _pkg = None
    if _pkg is not None:
        sys.modules.setdefault("dl_brain", _pkg)
        from dli_dist._vendor.dl_brain import executor as _ex
        sys.modules.setdefault("dl_brain.executor", _ex)
        _TIER = importlib.import_module("dl_brain.tier")
        return _TIER

    # Source checkout: the repo-root vendor directory, on the filesystem.
    root = _vendor_root()
    if not (root / "dl_brain" / "tier.py").is_file():
        raise TierAbsent(
            f"no vendored tier: neither the packaged dli_dist._vendor.dl_brain nor "
            f"{root / 'dl_brain' / 'tier.py'} is present — this build declares "
            f"tier_sha {_build.TIER_SHA} but does not carry it"
        )
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    _TIER = importlib.import_module("dl_brain.tier")
    return _TIER


def resolve_model_client(spec: str | None = None) -> Any:
    """Build the embedder's model client from ``DLI_MODEL_CLIENT``.

    ``module:factory``. The factory is called with no arguments and must return
    an object with ``complete(prompt, *, purpose) -> str``. Nothing about the
    transport is this package's business — which is what keeps the package free
    of network imports while the binary honestly declares that it needs one.
    """
    spec = spec if spec is not None else os.environ.get(MODEL_CLIENT_ENV)
    if not spec:
        raise ModelClientAbsent(
            f"{MODEL_CLIENT_ENV} is unset. A level above DL0 constructs what the "
            "contract did not supply and cannot do that without a model client. "
            "Set it to 'module:factory'."
        )
    module_name, sep, attr = spec.partition(":")
    if not sep or not module_name or not attr:
        raise ModelClientAbsent(f"{MODEL_CLIENT_ENV}={spec!r} is not 'module:factory'")
    try:
        factory = getattr(importlib.import_module(module_name), attr)
    except (ImportError, AttributeError) as exc:
        raise ModelClientAbsent(f"{MODEL_CLIENT_ENV}={spec!r} did not resolve: {exc}") from exc
    client = factory()
    if not callable(getattr(client, "complete", None)):
        raise ModelClientAbsent(
            f"{MODEL_CLIENT_ENV}={spec!r} produced {type(client).__name__}, which has "
            "no callable complete(prompt, *, purpose)"
        )
    return client


def run_tier_contract(
    contract: dict[str, Any],
    *,
    level: str,
    executor_id: str,
    acceptance_role: bool,
    plans: bool,
    model_client: Any = None,
) -> dict[str, Any]:
    """Run one contract at ``level`` and return ``{"record", "exit_code"}``.

    Mirrors ``dl0.execute``: kappa is read from the pinned benchmark and refused
    if unprovenanced *before* any work runs, the run detail goes to an artifact,
    and the returned record carries no verdict.
    """
    if "task_id" not in contract:
        raise ContractError("contract missing required field 'task_id'")

    # kappa read (never chosen), loss and acceptance copied from the brain's
    # blocks. An invented kappa is refused here, before anything is spent.
    blocks = resolve_blocks(contract)

    tier = vendored_tier()

    # The refusal decision, before a client is even looked for. A binary that
    # needed a credential to decline a contract would have made its declared
    # limit conditional on one.
    if model_client is None:
        model_client = (
            RefusalOnlyClient() if not tier.admits(level, contract) else resolve_model_client()
        )

    out = Path(contract.get("artifacts_dir") or tempfile.mkdtemp(prefix=f"{executor_id}-"))
    out.mkdir(parents=True, exist_ok=True)

    ex = tier.executor_for(
        level, model_client=model_client, executor_id=executor_id, artifacts_dir=str(out)
    )
    res = ex.execute(contract)

    run_record = {
        "executor_id": executor_id,
        "level": level,
        "plans": plans,
        "task_id": res.task_id,
        "argv": list(res.argv),
        "exit_code": res.exit_code,
        "started_at": res.started_at,
        "ended_at": res.ended_at,
        "replans": res.replans,
        "model_calls": sum(1 for e in res.trace if e.get("kind") == "model_call"),
        "model_call_purposes": [
            e.get("purpose") for e in res.trace if e.get("kind") == "model_call"
        ],
        "failure_class": res.failure_class.value if res.failure_class else None,
        "artifacts": dict(res.artifacts),
    }
    run_file = out / "execution_result.json"
    run_file.write_text(json.dumps(run_record, indent=2, sort_keys=True), encoding="utf-8")

    evidence = {"execution_result": str(run_file)}
    evidence.update(dict(res.artifacts))

    # A real, re-derivable subtraction of the two recorded instants — not a
    # duration the executor was free to author.
    latency = (
        episode.parse_instant(res.ended_at) - episode.parse_instant(res.started_at)
    ).total_seconds()

    record = episode.draft_episode(
        task_id=res.task_id,
        task_band=contract.get("predicted_band", "T1"),
        kappa=blocks["kappa"],
        intervention_budget=contract.get("intervention_budget", "H0"),
        executor=executor_id,
        acceptance_role=acceptance_role,  # False: a performer may never self-certify (F6).
        replans=res.replans,
        latency_seconds=max(latency, 0.0),
        loss=blocks["loss"],
        acceptance=blocks["acceptance"],
        evidence=evidence,
        held_level=level,
        opened_level=level,
        failure_class=res.failure_class.value if res.failure_class else None,
        executor_stub=False,
        # UNMEASURED, not zero. No model credential exists on this account, so no
        # invocation here was ever billed; `null` is this lane's idiom for
        # unmeasured and 0.0 would be a claim about a level that makes calls.
        compute_cost=res.compute_cost_usd,
        benchmark_assets_present=False,
    )
    return {"record": record, "exit_code": res.exit_code}


def main(
    argv: list[str], *, executor_id: str, execute: Callable[[dict], dict[str, Any]]
) -> int:
    """``exec --contract c.json`` for one tier binary. Returns a process exit code."""
    contract_path = None
    it = iter(argv)
    for tok in it:
        if tok == "--contract":
            contract_path = next(it, None)
    if not contract_path:
        sys.stderr.write(f"usage: {executor_id} exec --contract <c.json>\n")
        return EXIT_USAGE
    try:
        contract = json.loads(Path(contract_path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        sys.stderr.write(f"could not read/parse contract {contract_path!r}: {exc}\n")
        return EXIT_USAGE
    try:
        outcome = execute(contract)
    except kappa.KappaPermissionError as exc:
        sys.stderr.write(f"REFUSED (charter: unpermitted benchmark row): {exc}\n")
        return EXIT_CHARTER
    except kappa.KappaProvenanceError as exc:
        sys.stderr.write(f"REFUSED (kappa provenance): {exc}\n")
        return EXIT_REFUSED
    except ContractError as exc:
        sys.stderr.write(f"REFUSED ({exc.failure_class}): {exc}\n")
        return EXIT_REFUSED
    except TierAbsent as exc:
        sys.stderr.write(f"UNAVAILABLE (vendored tier absent): {exc}\n")
        return EXIT_TIER_ABSENT
    except ModelClientAbsent as exc:
        # Not a stub and not a refusal: a precondition of the environment is
        # missing. The binary is real, the contract may be fine, and there is no
        # model client to run it with.
        sys.stderr.write(f"UNAVAILABLE (no model client): {exc}\n")
        return EXIT_NO_MODEL_CLIENT
    except episode.EpisodeInvalid as exc:
        sys.stderr.write(f"could not build a valid episode record: {exc}\n")
        return EXIT_RECORD_INVALID
    json.dump(outcome["record"], sys.stdout, ensure_ascii=False)
    sys.stdout.write("\n")
    return outcome["exit_code"]
